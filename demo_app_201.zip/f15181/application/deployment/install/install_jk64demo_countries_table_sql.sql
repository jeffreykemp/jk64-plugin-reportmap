prompt --application/deployment/install/install_jk64demo_countries_table_sql
begin
--   Manifest
--     INSTALL: INSTALL-jk64demo_countries_table.sql
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>15181
,p_default_id_offset=>0
,p_default_owner=>'JK64'
);
wwv_flow_api.create_install_script(
 p_id=>wwv_flow_api.id(54436174521698930)
,p_install_id=>wwv_flow_api.id(54431867465452579)
,p_name=>'jk64demo_countries_table.sql'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create table jk64demo_countries',
'( country varchar2(255) not null',
', iso_a2 varchar2(2)',
', iso_a3 varchar2(3)',
', lat number',
', lng number',
', geometry clob',
', constraint country_name_uk unique (country)',
', constraint iso_a2_uk unique (iso_a2)',
', constraint iso_a3_uk unique (iso_a3)',
', constraint geometry_is_json check (geometry is json)',
');',
''))
);
wwv_flow_api.component_end;
end;
/
