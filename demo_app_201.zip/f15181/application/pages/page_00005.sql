prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>15181
,p_default_id_offset=>0
,p_default_owner=>'JK64'
);
wwv_flow_api.create_page(
 p_id=>5
,p_user_interface_id=>wwv_flow_api.id(25186303948932505463)
,p_name=>'Search Map'
,p_alias=>'SEARCH'
,p_step_title=>'Search Map'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Enter a <b>Search</b> string - e.g. an address, place name or landmark. The item has an onchange dynamic action that executes the following:',
'<code>',
'    $("#map_mymap").reportmap("gotoAddress",$v(this.triggeringElement));',
'</code>',
'<p>',
'When it is found, the map raises the <strong>addressFound</strong> event.',
'<p>',
'A dynamic action on the region then executes the following Actions:',
'<ol><li>Execute JavaScript Code:',
'<code>',
'    this.data.map.setCenter({lat:this.data.lat,lng:this.data.lng});',
'    this.data.map.setZoom(17);',
'</code>',
'</li><li>Set Value, on item P5_ADDRESS, to JavaScript Expression:',
'<code>',
'    this.data.result.formatted_address',
'</code>',
'</li><li>Set Value, on item P5_DSP_LAT_LNG, to JavaScript Expression:',
'<code>',
'    this.data.lat + " " + this.data.lng);',
'</code>',
'</li></ol>',
'<p>',
'Alternatively, if you click any point on the map, the <strong>mapClick</strong> event fires and a dynamic action executes:',
'<code>',
'    //place the user pin at the point they clicked',
'    $("#map_mymap").reportmap("gotoPos",this.data.lat,this.data.lng);',
'',
'    //execute a geocoder search',
'    $("#map_mymap").reportmap("getAddressByPos",this.data.lat,this.data.lng);',
'</code>',
'<p>',
'The maps "Draggable" option is set. This means the marker can be dragged to a new location; when this occurs, the <strong>markerDrag</strong> event fires and a',
'dynamic action calls <code>getAddressByPos</code> again.',
'<p>',
'If the <b>Region</b> is selected, the search will <em>bias</em> the results to the selected region if multiple results are found.',
'<p>',
'If the <b>Country</b> is selected, the results will be <em>restricted</em> to the selected country.',
'<p>',
'When the Country is changed, a dynamic action performs two actions:',
'<ol>',
'<li>Set Value - retrieves the lat,lng for the country into P5_LATLNG</li>',
'<li>Javascript:',
'    <code>',
'        $("#map_mymap").reportmap("option","restrictCountry",$v("P5_COUNTRY"));',
'        var ctr = $("#map_mymap").reportmap("parseLatLng",$v("P5_LATLNG"));',
'        $("#map_mymap").reportmap("instance").map.setCenter(ctr);',
'    </code>',
'</li>',
'</ol>',
'This demonstrates how to modify one of the plugin options at runtime, how to convert a string to a Google Maps LatLng object, and how to execute arbitrary Google Maps API calls.',
'</p>'))
,p_page_comment=>'This page requires the table jk64demo_countries.'
,p_last_updated_by=>'JEFF'
,p_last_upd_yyyymmddhh24miss=>'20200520083038'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(22167236053368435)
,p_plug_name=>'Notes'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(25186277719855505424)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_HELP_TEXT'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(32938247034408714)
,p_plug_name=>'Search Map'
,p_region_name=>'mymap'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(25186269690704505415)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'600'
,p_attribute_02=>'PINS'
,p_attribute_03=>'13'
,p_attribute_04=>'PAN_ON_CLICK:DRAGGABLE:PAN_ALLOWED:ZOOM_ALLOWED:SPINNER'
,p_attribute_06=>'&P5_LATLNG.'
,p_attribute_09=>'&P5_REGION.'
,p_attribute_10=>'&P5_COUNTRY.'
,p_attribute_12=>'N'
,p_attribute_21=>'N'
,p_attribute_22=>'ROADMAP'
,p_attribute_24=>'Y'
,p_attribute_25=>'auto'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(53974978684556304)
,p_name=>'P5_REGION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(22167236053368435)
,p_prompt=>'Bias to Region'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select country, iso_a2 from jk64demo_countries where iso_a2 is not null order by 1'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'default bias (US)'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(33868269191697067)
,p_item_icon_css_classes=>'fa-globe'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'REDIRECT_SET_VALUE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(70256251299092631)
,p_name=>'P5_SEARCH'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(22167236053368435)
,p_prompt=>'Search'
,p_placeholder=>'enter address to search for'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_field_template=>wwv_flow_api.id(33868269191697067)
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(70256306778092632)
,p_name=>'P5_ADDRESS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(22167236053368435)
,p_prompt=>'Address'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'readonly'
,p_field_template=>wwv_flow_api.id(33868269191697067)
,p_item_icon_css_classes=>'fa-envelope-square'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(70256464164092633)
,p_name=>'P5_COUNTRY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(22167236053368435)
,p_prompt=>'Restrict to Country'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select country, iso_a2 from jk64demo_countries where iso_a2 is not null and lat is not null and lng is not null order by 1'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'(all countries)'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(33868269191697067)
,p_item_icon_css_classes=>'fa-map-marker'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(70256530354092634)
,p_name=>'P5_LATLNG'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(22167236053368435)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(102156918047353009)
,p_name=>'P5_DSP_LAT_LNG'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(22167236053368435)
,p_prompt=>'Lat/Long'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'readonly'
,p_field_template=>wwv_flow_api.id(33868269191697067)
,p_item_icon_css_classes=>'fa-map-pin'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(70256859857092637)
,p_computation_sequence=>10
,p_computation_item=>'P5_LATLNG'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT lat||'',''||lng',
'FROM jk64demo_countries',
'WHERE iso_a2 = :P5_COUNTRY'))
,p_compute_when=>'P5_COUNTRY'
,p_compute_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(102156728439353007)
,p_name=>'addressFound'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(32938247034408714)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|addressfound'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(102156898191353008)
,p_event_id=>wwv_flow_api.id(102156728439353007)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'this.data.map.setCenter({lat:this.data.lat,lng:this.data.lng});',
'this.data.map.setZoom(17);'))
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33391528882218415)
,p_event_id=>wwv_flow_api.id(102156728439353007)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P5_ADDRESS'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.data.result.formatted_address'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33391652411218416)
,p_event_id=>wwv_flow_api.id(102156728439353007)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P5_LATLNG,P5_DSP_LAT_LNG'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.data.lat + " " + this.data.lng'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(22166137092368424)
,p_name=>'on search'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P5_SEARCH'
,p_condition_element=>'P5_SEARCH'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(22166279568368425)
,p_event_id=>wwv_flow_api.id(22166137092368424)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#map_mymap").reportmap("gotoAddress",$v(this.triggeringElement));'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(22167710187368440)
,p_name=>'mapclick - get address'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(32938247034408714)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|mapclick'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(22167882306368441)
,p_event_id=>wwv_flow_api.id(22167710187368440)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'//place the user pin at the point they clicked',
'$("#map_mymap").reportmap("gotoPos",this.data.lat,this.data.lng);',
'',
'//execute a geocoder search',
'$("#map_mymap").reportmap("getAddressByPos",this.data.lat,this.data.lng);'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(53977082197556325)
,p_name=>'markerDrag'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(32938247034408714)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|markerdrag'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(53977164774556326)
,p_event_id=>wwv_flow_api.id(53977082197556325)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'//execute a geocoder search',
'$("#map_mymap").reportmap("getAddressByPos",this.data.lat,this.data.lng);'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(32938383315408715)
,p_name=>'on change country'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P5_COUNTRY'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(32938401649408716)
,p_event_id=>wwv_flow_api.id(32938383315408715)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P5_LATLNG'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT lat||'',''||lng',
'FROM jk64demo_countries',
'WHERE iso_a2 = :P5_COUNTRY'))
,p_attribute_07=>'P5_COUNTRY'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(32938538624408717)
,p_event_id=>wwv_flow_api.id(32938383315408715)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#map_mymap").reportmap("option","restrictCountry",$v("P5_COUNTRY"));',
'var ctr = $("#map_mymap").reportmap("parseLatLng",$v("P5_LATLNG"));',
'$("#map_mymap").reportmap("instance").map.setCenter(ctr);'))
);
wwv_flow_api.component_end;
end;
/
