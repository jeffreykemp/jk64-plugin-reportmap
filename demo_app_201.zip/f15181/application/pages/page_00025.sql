prompt --application/pages/page_00025
begin
--   Manifest
--     PAGE: 00025
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>15181
,p_default_id_offset=>0
,p_default_owner=>'JK64'
);
wwv_flow_api.create_page(
 p_id=>25
,p_user_interface_id=>wwv_flow_api.id(25186303948932505463)
,p_name=>'Custom Marker Format'
,p_alias=>'CUSTOMMARKER'
,p_step_title=>'Custom Marker Format'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'The page provides a function to the plugin to supply custom code to format each marker or manipulate it in other ways.',
'<p>',
'    Each marker is a <b><a href="https://developers.google.com/maps/documentation/javascript/reference/marker#Marker" target=_blank>google.maps.Marker</a></b> object with the following attributes (among others), most of which may be changed by your f'
||'unction:',
'<ul>',
'    <li><b>data.id</b> = source query id</li>',
'    <li><b>data.name</b> = source query name</li>',
'    <li><b>data.info</b> = source query info</li>',
'    <li><b>title</b> = based on source query name by default</li>',
'    <li><b>icon</b> = based on source query icon by default, plus baseIconPath if set</li>',
'    <li><b>label</b> = based on source query label</li>',
'    <li><b>position</b> = google.maps.LatLng object</li>',
'    <li><b>data.attr01</b>, <b>data.attr02</b>, .. <b>data.attr10</b> = source query flex fields</li>',
'</ul>',
'You can also call Google Maps API methods on the Marker object, such as setAnimation, setOpacity, setDraggable, etc.',
'<p>',
'Note that the marker.icon property can be a URL to an image to show, or to a <a href="https://developers.google.com/maps/documentation/javascript/symbols" target=_blank>Symbol</a>.'))
,p_last_updated_by=>'JEFF'
,p_last_upd_yyyymmddhh24miss=>'20200520083038'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(53977371832556328)
,p_plug_name=>'Custom Marker Formatter #2'
,p_region_name=>'mymap2'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(25186269690704505415)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c003 as lat, c004 as lng, c005 as name, c001 as id, c002 || '' (pop='' || c005 || '')'' as info, '''' as icon, c002 as lbl',
'      ,c005 as attr01',
'from apex_collections',
'where collection_name = ''MAP''',
'and (c003,c004) not in ((0,0))',
'and c005 is not null'))
,p_plug_source_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'this.options.markerFormatFn = function(marker) {',
'',
'    var population = parseFloat(marker.data.attr01);',
'',
'    // icon can be a Symbol',
'    marker.icon = {',
'      path          : google.maps.SymbolPath.CIRCLE,',
'      fillColor     : "#dd0000",',
'      fillOpacity   : 0.6,',
'      strokeColor   : "#0000dd",',
'      strokeOpacity : 0.9,',
'      strokeWeight  : 1,',
'      scale         : 5 * Math.log(population)',
'    };',
'',
'}'))
,p_attribute_01=>'350'
,p_attribute_02=>'PINS'
,p_attribute_03=>'13'
,p_attribute_04=>'PAN_ON_CLICK:PAN_ALLOWED:ZOOM_ALLOWED:SPINNER'
,p_attribute_11=>'[{"featureType":"all","elementType":"geometry","stylers":[{"color":"#4740a0"}]},{"featureType":"all","elementType":"labels.text.fill","stylers":[{"gamma":0.01},{"lightness":20}]},{"featureType":"all","elementType":"labels.text.stroke","stylers":[{"sa'
||'turation":-31},{"lightness":-33},{"weight":2},{"gamma":0.8}]},{"featureType":"all","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"administrative","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"adm'
||'inistrative","elementType":"labels","stylers":[{"visibility":"simplified"},{"weight":"0.50"}]},{"featureType":"administrative","elementType":"labels.text","stylers":[{"visibility":"off"}]},{"featureType":"administrative","elementType":"labels.text.st'
||'roke","stylers":[{"weight":"0.50"}]},{"featureType":"administrative.locality","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"landscape","elementType":"all","stylers":[{"visibility":"simplified"},{"color":"#e1e1e1"}]},{"featureT'
||'ype":"landscape","elementType":"geometry","stylers":[{"lightness":30},{"saturation":30}]},{"featureType":"landscape.natural","elementType":"all","stylers":[{"visibility":"on"}]},{"featureType":"landscape.natural","elementType":"labels","stylers":[{"v'
||'isibility":"off"}]},{"featureType":"landscape.natural.landcover","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"poi","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"poi","elementType":"geometry","stylers":'
||'[{"saturation":20}]},{"featureType":"poi.park","elementType":"geometry","stylers":[{"lightness":20},{"saturation":-20}]},{"featureType":"road","elementType":"all","stylers":[{"visibility":"on"}]},{"featureType":"road","elementType":"geometry","styler'
||'s":[{"lightness":10},{"saturation":-30}]},{"featureType":"road","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#8a8a8a"}]},{"featureType":"road","elementType":"geometry.stroke","stylers":[{"saturation":25},{"lightness":25}]},{'
||'"featureType":"road","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"road.highway","elementType":"all","stylers":[{"visibility":"on"},{"hue":"#ff0000"}]},{"featureType":"road.highway","elementType":"labels","stylers":[{"visib'
||'ility":"off"}]},{"featureType":"road.highway","elementType":"labels.text","stylers":[{"visibility":"off"}]},{"featureType":"road.arterial","elementType":"all","stylers":[{"visibility":"on"}]},{"featureType":"road.arterial","elementType":"labels","sty'
||'lers":[{"visibility":"off"}]},{"featureType":"road.local","elementType":"all","stylers":[{"visibility":"on"}]},{"featureType":"transit","elementType":"all","stylers":[{"visibility":"on"},{"color":"#1bc984"}]},{"featureType":"transit","elementType":"l'
||'abels","stylers":[{"visibility":"off"}]},{"featureType":"transit.line","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"transit.station.airport","elementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"transit.statio'
||'n.airport","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#b4b4b4"}]},{"featureType":"transit.station.airport","elementType":"labels","stylers":[{"visibility":"simplified"},{"weight":"1.00"},{"color":"#e50c0c"}]},{"featureType'
||'":"transit.station.airport","elementType":"labels.text","stylers":[{"visibility":"off"}]},{"featureType":"transit.station.airport","elementType":"labels.icon","stylers":[{"weight":"1.25"},{"color":"#00b3fb"}]},{"featureType":"transit.station.rail","e'
||'lementType":"all","stylers":[{"visibility":"off"}]},{"featureType":"transit.station.rail","elementType":"geometry","stylers":[{"visibility":"off"}]},{"featureType":"water","elementType":"all","stylers":[{"lightness":-20},{"visibility":"on"}]},{"featu'
||'reType":"water","elementType":"geometry.fill","stylers":[{"color":"#ffffff"}]},{"featureType":"water","elementType":"labels.text","stylers":[{"visibility":"off"}]}]'
,p_attribute_12=>'N'
,p_attribute_21=>'N'
,p_attribute_22=>'ROADMAP'
,p_attribute_24=>'Y'
,p_attribute_25=>'auto'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(53977576467556330)
,p_plug_name=>'JavaScript Initialization Code'
,p_parent_plug_id=>wwv_flow_api.id(53977371832556328)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(25186277719855505424)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<code>this.options.markerFormatFn = function(marker) {',
'',
'    var population = parseFloat(marker.data.attr01);',
'',
'    // icon can be a Symbol',
'    marker.icon = {',
'      path          : google.maps.SymbolPath.CIRCLE,',
'      fillColor     : "#dd0000",',
'      fillOpacity   : 0.6,',
'      strokeColor   : "#0000dd",',
'      strokeOpacity : 0.9,',
'      strokeWeight  : 1,',
'      scale         : 5 * Math.log(population)',
'    };',
'',
'}',
'</code>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(87084137971692016)
,p_plug_name=>'Custom Marker Formatter #1'
,p_region_name=>'mymap1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(25186269690704505415)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c003 as lat, c004 as lng, c002 as name, c001 as id, c002 || '' (id='' || c001 || '')'' as info',
'from apex_collections',
'where collection_name = ''MAP''',
'and (c003,c004) not in ((0,0))'))
,p_plug_source_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'this.options.markerFormatFn = function(marker) {',
'',
'    // icon can be a URL to an icon image',
'    marker.icon = ''https://mt.googleapis.com/vt/icon/name=icons/spotlight/''',
'        + ((marker.data.id % 2 == 0)',
'           ? ''spotlight-waypoint-blue.png''',
'           : ''spotlight-waypoint-a.png'')',
'        + ''&scale=1.5'';',
'',
'    // you can change other attributes of the marker as well',
'    marker.title = marker.data.name.toUpperCase();',
'    ',
'    // we can call google.maps.Marker object methods as well',
'    marker.setOpacity(0.5);',
'',
'    if (marker.title == ''HOME'') {',
'        // we can shift the marker position',
'        marker.setPosition( {lat: -31.82531, lng: 115.84366} );',
'    }',
'}'))
,p_attribute_01=>'350'
,p_attribute_02=>'PINS'
,p_attribute_03=>'13'
,p_attribute_04=>'PAN_ON_CLICK:PAN_ALLOWED:ZOOM_ALLOWED:SPINNER'
,p_attribute_11=>'[{"featureType":"all","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"all","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"administrative","elementType":"all","stylers":[{"visibility":"off"}]},{"'
||'featureType":"landscape.man_made","elementType":"all","stylers":[{"visibility":"simplified"}]},{"featureType":"landscape.man_made","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#000000"}]},{"featureType":"landscape.man_made",'
||'"elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"landscape.man_made","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"landscape.natural.landcover","elementType":"geometry.fill","stylers":[{"color":'
||'"#e1e1e1"}]},{"featureType":"landscape.natural.terrain","elementType":"geometry.fill","stylers":[{"color":"#e1e1e1"}]},{"featureType":"poi","elementType":"geometry","stylers":[{"visibility":"simplified"}]},{"featureType":"poi","elementType":"labels",'
||'"stylers":[{"visibility":"off"}]},{"featureType":"poi.attraction","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#000000"}]},{"featureType":"poi.attraction","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featu'
||'reType":"poi.business","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#000000"}]},{"featureType":"poi.government","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#000000"}]},{"featureType":"poi.medical",'
||'"elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#000000"}]},{"featureType":"poi.park","elementType":"geometry.fill","stylers":[{"color":"#e1e1e1"},{"visibility":"on"}]},{"featureType":"poi.place_of_worship","elementType":"geome'
||'try.fill","stylers":[{"color":"#000000"}]},{"featureType":"poi.school","elementType":"geometry.fill","stylers":[{"color":"#000000"}]},{"featureType":"poi.sports_complex","elementType":"geometry.fill","stylers":[{"color":"#b4b4b4"},{"visibility":"on"}'
||']},{"featureType":"road","elementType":"all","stylers":[{"saturation":-100},{"lightness":45},{"visibility":"simplified"}]},{"featureType":"road","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#ffffff"}]},{"featureType":"road",'
||'"elementType":"geometry.stroke","stylers":[{"visibility":"off"}]},{"featureType":"road","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"road","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"trans'
||'it","elementType":"all","stylers":[{"visibility":"simplified"}]},{"featureType":"transit.line","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#ffffff"}]},{"featureType":"transit.station","elementType":"geometry.fill","stylers"'
||':[{"color":"#323232"},{"visibility":"on"}]},{"featureType":"transit.station","elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"water","elementType":"all","stylers":[{"color":"#ffffff"},{"visibility":"on"}]},{"featureType":'
||'"water","elementType":"labels","stylers":[{"visibility":"off"}]}]'
,p_attribute_12=>'N'
,p_attribute_21=>'N'
,p_attribute_22=>'ROADMAP'
,p_attribute_24=>'Y'
,p_attribute_25=>'auto'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(53977480039556329)
,p_plug_name=>'JavaScript Initialization Code'
,p_parent_plug_id=>wwv_flow_api.id(87084137971692016)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(25186277719855505424)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<code>this.options.markerFormatFn = function(marker) {',
'',
'    // icon can be a URL to an icon image',
'    marker.icon = ''https://mt.googleapis.com/vt/icon/name=icons/spotlight/''',
'        + ((marker.data.id % 2 == 0)',
'           ? ''spotlight-waypoint-blue.png''',
'           : ''spotlight-waypoint-a.png'')',
'        + ''&scale=1.5'';',
'',
'    // you can change other attributes of the marker as well',
'    marker.title = marker.data.name.toUpperCase();',
'    ',
'    // we can call google.maps.Marker object methods as well',
'    marker.setOpacity(0.5);',
'',
'    if (marker.title == ''HOME'') {',
'        // we can shift the marker position',
'        marker.setPosition( {lat: -31.82531, lng: 115.84366} );',
'    }',
'}',
'</code>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(164044021252719866)
,p_plug_name=>'Notes'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(25186277719855505424)
,p_plug_display_sequence=>40
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_HELP_TEXT'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.component_end;
end;
/
