prompt --application/pages/page_00026
begin
--   Manifest
--     PAGE: 00026
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>15181
,p_default_id_offset=>0
,p_default_owner=>'JK64'
);
wwv_flow_api.create_page(
 p_id=>26
,p_user_interface_id=>wwv_flow_api.id(25186303948932505463)
,p_name=>'Batched Results'
,p_alias=>'BATCHED'
,p_step_title=>'Batched Results'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'The Rows Per Batch plugin attribute has been set to 1000. This causes the plugin to load the pins in multiple ajax calls. Using this attribute increases the overall time required to load all the data, but allows the map to start showing some pins ear'
||'lier, making it more user-friendly.',
'<p>',
'As each batch is received, the map will expand the bounds (pan & zoom) to show the new pins.',
'<p>',
'As each intermediate batch is received, the <b>batchLoaded</b> event fires. It usually does not fire after the last batch, although it is possible (in the edge case when the total rows is an exact multiple of the batch size).',
'<p>',
'When the last batch is received, the <b>mapLoaded</b> event fires.',
'<p>',
'<hr>',
'<em>Side note:</em> for the marker styling, the <b>JavaScript Initialization Code</b> is:',
'<code>',
'this.options.markerFormatFn = function(marker, flex) {',
'    var mag = parseFloat(flex.a1)',
'       ,iconName;',
'',
'    if (mag > 4.5) {',
'        iconName = ''capital_small_highlight.png'';',
'    } else if (mag > 3.0) {',
'        iconName = ''capital_small.png'';',
'    } else if (mag > 1.5) {',
'        iconName = ''placemark_circle_highlight.png'';',
'    } else {',
'        iconName = ''placemark_circle.png'';',
'    }',
'    ',
'    // these icons are 32x32 images, more-or-less centered',
'    ',
'    marker.icon = {',
'        url: ''https://maps.google.com/mapfiles/kml/shapes/'' + iconName,',
'        anchor: new google.maps.Point(15, 16)',
'    };',
'    ',
'    marker.title = ''Magnitude:'' + flex.a1;',
'',
'    marker.setOpacity(0.5);',
'}',
'</code>'))
,p_last_updated_by=>'JEFF'
,p_last_upd_yyyymmddhh24miss=>'20200520083038'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(192220682381606272)
,p_plug_name=>'Batched Results'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(25186277719855505424)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_HELP_TEXT'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3333187100956175452)
,p_plug_name=>'Report Google Map Plugin ("mymap")'
,p_region_name=>'mymap'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(25186269690704505415)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select lat, lng, '''' name, '''' id, '''' info, '''' icon, '''' label, mag as flex1',
'from jk64demo_earthquakes'))
,p_plug_source_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'this.options.markerFormatFn = function(marker) {',
'    var mag = parseFloat(marker.data.attr01)',
'       ,iconName;',
'',
'    if (mag > 4.5) {',
'        iconName = ''capital_small_highlight.png'';',
'    } else if (mag > 3.0) {',
'        iconName = ''capital_small.png'';',
'    } else if (mag > 1.5) {',
'        iconName = ''placemark_circle_highlight.png'';',
'    } else {',
'        iconName = ''placemark_circle.png'';',
'    }',
'    ',
'    // these icons are 32x32 images, more-or-less centered',
'    ',
'    marker.icon = {',
'        url: ''https://maps.google.com/mapfiles/kml/shapes/'' + iconName,',
'        anchor: new google.maps.Point(15, 16)',
'    };',
'    ',
'    marker.title = ''Magnitude:'' + marker.data.attr01;',
'',
'    marker.setOpacity(0.5);',
'}'))
,p_attribute_01=>'400'
,p_attribute_02=>'PINS'
,p_attribute_04=>'PAN_ON_CLICK:PAN_ALLOWED:ZOOM_ALLOWED:DISABLEFITBOUNDS:SPINNER'
,p_attribute_07=>'1000'
,p_attribute_12=>'N'
,p_attribute_21=>'N'
,p_attribute_22=>'ROADMAP'
,p_attribute_24=>'Y'
,p_attribute_25=>'auto'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(53975878892556313)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(192220682381606272)
,p_button_name=>'REFRESH'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(25186298860096505445)
,p_button_image_alt=>'Refresh'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(53975050793556305)
,p_name=>'P26_EXPECTED_ROWS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(192220682381606272)
,p_prompt=>'Expected Rows'
,p_source=>'select count(*) from jk64demo_earthquakes'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(25186298275602505444)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_item_comment=>'This page requires the table jk64demo_earthquakes.'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(53975119202556306)
,p_name=>'P26_ACTUAL_ROWS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(192220682381606272)
,p_prompt=>'Actual Rows'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(25186298275602505444)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(53975238968556307)
,p_name=>'mapLoaded'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(3333187100956175452)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|maploaded'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(53975313815556308)
,p_event_id=>wwv_flow_api.id(53975238968556307)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P26_ACTUAL_ROWS'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.data.countPins'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(53976127050556316)
,p_name=>'mapRefreshed'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(3333187100956175452)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|maprefreshed'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(53976282592556317)
,p_event_id=>wwv_flow_api.id(53976127050556316)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P26_ACTUAL_ROWS'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.data.countPins'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(53975499353556309)
,p_name=>'batchLoaded'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(3333187100956175452)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|batchloaded'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(53975530284556310)
,p_event_id=>wwv_flow_api.id(53975499353556309)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P26_ACTUAL_ROWS'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.data.countPins'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(53975979099556314)
,p_name=>'refresh region'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(53975878892556313)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(53976029843556315)
,p_event_id=>wwv_flow_api.id(53975979099556314)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(3333187100956175452)
);
wwv_flow_api.component_end;
end;
/
