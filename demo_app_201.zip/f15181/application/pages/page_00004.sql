prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>15181
,p_default_id_offset=>0
,p_default_owner=>'JK64'
);
wwv_flow_api.create_page(
 p_id=>4
,p_user_interface_id=>wwv_flow_api.id(25186303948932505463)
,p_name=>'Marker Clustering'
,p_alias=>'CLUSTERING'
,p_step_title=>'Marker Clustering'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>This map has Marker Clustering enabled.</strong>',
'<p>',
'Query for map plugin (this takes a random 10% sample to improve performance):',
'<code>',
'    select lat, lng,',
'           ''Magnitude '' || mag as name,',
'           lat||'',''||lng as id',
'    from jk64demo_earthquakes sample(10)',
'</code>',
'<p>',
'Dynamic action on plugin event <strong>markerClick</strong> sets P1_CLICKED.'))
,p_page_comment=>'This page requires the table jk64demo_earthquakes.'
,p_last_updated_by=>'JEFF'
,p_last_upd_yyyymmddhh24miss=>'20200520083038'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(32939470180408726)
,p_plug_name=>'Report Google Map Plugin'
,p_region_name=>'mymap'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(25186269690704505415)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>'select lat, lng, ''Magnitude '' || mag as name, lat||'',''||lng as id from jk64demo_earthquakes sample(10)'
,p_plug_source_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'350'
,p_attribute_02=>'CLUSTER'
,p_attribute_04=>'PAN_ON_CLICK:PAN_ALLOWED:ZOOM_ALLOWED:SPINNER'
,p_attribute_12=>'N'
,p_attribute_21=>'N'
,p_attribute_22=>'ROADMAP'
,p_attribute_24=>'Y'
,p_attribute_25=>'auto'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(105766656883857610)
,p_plug_name=>'Marker Clustering'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(25186277719855505424)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_HELP_TEXT'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(3246733271933426792)
,p_name=>'Source data'
,p_template=>wwv_flow_api.id(25186277719855505424)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>'select lat, lng, ''Magnitude '' || mag as name, lat||'',''||lng as id from jk64demo_earthquakes'
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(25186286576607505432)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32261494605619180)
,p_query_column_id=>1
,p_column_alias=>'LAT'
,p_column_display_sequence=>1
,p_column_heading=>'Lat'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32261766225619181)
,p_query_column_id=>2
,p_column_alias=>'LNG'
,p_column_display_sequence=>2
,p_column_heading=>'Lng'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32262100159619182)
,p_query_column_id=>3
,p_column_alias=>'NAME'
,p_column_display_sequence=>3
,p_column_heading=>'Name'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32262585402619182)
,p_query_column_id=>4
,p_column_alias=>'ID'
,p_column_display_sequence=>4
,p_column_heading=>'ID'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32263347067619182)
,p_name=>'P4_CLICKED'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(105766656883857610)
,p_prompt=>'P4_CLICKED'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(33868269191697067)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(32263764889619202)
,p_name=>'markerClick'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(32939470180408726)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|markerclick'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33393158320218431)
,p_event_id=>wwv_flow_api.id(32263764889619202)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P4_CLICKED'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'"this.data.id="+this.data.id+" this.data.name="+this.data.name+" this.data.lat="+this.data.lat+" this.data.lng="+this.data.lng'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.component_end;
end;
/
