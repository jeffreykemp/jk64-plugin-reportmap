prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>15181
,p_default_id_offset=>0
,p_default_owner=>'JK64'
);
wwv_flow_api.create_page(
 p_id=>11
,p_user_interface_id=>wwv_flow_api.id(25186303948932505463)
,p_name=>'Route Map'
,p_alias=>'ROUTE'
,p_step_title=>'Route Map'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>Visualisation: Directions</strong>',
'<p>',
'Show route directions between two points with some waypoints on the way. The first record returned by the query is taken as the starting point, and the last record is used as the end point for the journey.',
'<p>',
'Google Maps allows a maximum of 8 waypoints in addition to the origin and destination.',
'<p>',
'The Directions Panel is an ordinary APEX region with the following contents:',
'<code>',
'    &lt;div id="directionspanel">&lt;/div>',
'</code>',
'The <b>JavaScript Initialization Code</b> on the plugin is: ',
'<code>',
'    this.options.directionsPanel = "directionspanel";',
'</code>',
'<p>',
'If the "Optimize Waypoints" plugin attribute is switched on, the map would reorder the intermediate waypoints to minimize the route cost.',
'<p>',
'A dynamic action on the region responds to the "directions" event with this javascript:',
'<code>',
'    $s("P11_DISTANCE",this.data.distance);',
'    $s("P11_DURATION",this.data.duration);',
'    $s("P11_LEGS",this.data.legs);',
'</code>'))
,p_last_updated_by=>'JEFF'
,p_last_upd_yyyymmddhh24miss=>'20200520083038'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(22167390620368436)
,p_plug_name=>'column2'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(25186269690704505415)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(110570584726744336)
,p_name=>'Source data'
,p_parent_plug_id=>wwv_flow_api.id(22167390620368436)
,p_template=>wwv_flow_api.id(25186277719855505424)
,p_display_sequence=>60
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c003 as lat, c004 as lng, c002 as name, c001 as id, c002 || '' (id='' || c001 || '')'' as info ',
'from apex_collections',
'where collection_name = ''ROUTE''',
'order by c001'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(25186286576607505432)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(110570954876744339)
,p_query_column_id=>1
,p_column_alias=>'LAT'
,p_column_display_sequence=>1
,p_column_heading=>'Lat'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(110571341825744341)
,p_query_column_id=>2
,p_column_alias=>'LNG'
,p_column_display_sequence=>2
,p_column_heading=>'Lng'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(110571783425744341)
,p_query_column_id=>3
,p_column_alias=>'NAME'
,p_column_display_sequence=>3
,p_column_heading=>'Name'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(110572146362744341)
,p_query_column_id=>4
,p_column_alias=>'ID'
,p_column_display_sequence=>4
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(110572562714744341)
,p_query_column_id=>5
,p_column_alias=>'INFO'
,p_column_display_sequence=>5
,p_column_heading=>'Info'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(110574138430744347)
,p_plug_name=>'Route Map'
,p_parent_plug_id=>wwv_flow_api.id(22167390620368436)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(25186277719855505424)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_HELP_TEXT'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(53975790849556312)
,p_plug_name=>'column1'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(25186277719855505424)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(32938967914408721)
,p_plug_name=>'Report Google Map Plugin'
,p_region_name=>'mymap'
,p_parent_plug_id=>wwv_flow_api.id(53975790849556312)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(25186269690704505415)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c003 as lat, c004 as lng, c002 as name, c001 as id, c002 || '' (id='' || c001 || '')'' as info',
'from apex_collections',
'where collection_name = ''ROUTE''',
'order by c001'))
,p_plug_source_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plugin_init_javascript_code=>'this.options.directionsPanel = "directionspanel";'
,p_attribute_01=>'500'
,p_attribute_02=>'DIRECTIONS'
,p_attribute_03=>'13'
,p_attribute_04=>'PAN_ON_CLICK:PAN_ALLOWED:ZOOM_ALLOWED:SPINNER'
,p_attribute_12=>'N'
,p_attribute_15=>'DRIVING'
,p_attribute_21=>'N'
,p_attribute_22=>'ROADMAP'
,p_attribute_24=>'Y'
,p_attribute_25=>'auto'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(53975679259556311)
,p_plug_name=>'Directions Panel'
,p_parent_plug_id=>wwv_flow_api.id(53975790849556312)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(25186277719855505424)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source=>'<div id="directionspanel"></div>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(22167699338368439)
,p_name=>'P11_LEGS'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(110574138430744347)
,p_prompt=>'Legs'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_column=>7
,p_field_template=>wwv_flow_api.id(33868269191697067)
,p_item_icon_css_classes=>'fa-map-signs'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(110652627730935336)
,p_name=>'P11_DISTANCE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(110574138430744347)
,p_prompt=>'Distance'
,p_post_element_text=>'m'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(33868269191697067)
,p_item_icon_css_classes=>'fa-fit-to-width'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(110653053445935338)
,p_name=>'P11_DISTANCE_KM'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(110574138430744347)
,p_post_element_text=>'km'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(33868269191697067)
,p_item_icon_css_classes=>'fa-fit-to-width'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(110653418369935338)
,p_name=>'P11_DURATION'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(110574138430744347)
,p_prompt=>'Duration'
,p_post_element_text=>'s'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(33868269191697067)
,p_item_icon_css_classes=>'fa-clock-o'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(110653830285935338)
,p_name=>'P11_DURATION_MI'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(110574138430744347)
,p_post_element_text=>'m'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(33868269191697067)
,p_item_icon_css_classes=>'fa-clock-o'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(109722918116796639)
,p_name=>'set distance km'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P11_DISTANCE'
,p_condition_element=>'P11_DISTANCE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(109723002945796640)
,p_event_id=>wwv_flow_api.id(109722918116796639)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s("P11_DISTANCE_KM", Math.round(parseFloat($v("P11_DISTANCE"))/1000));'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(109723123426796641)
,p_name=>'set duration mi'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P11_DURATION'
,p_condition_element=>'P11_DURATION'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(109723297625796642)
,p_event_id=>wwv_flow_api.id(109723123426796641)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s("P11_DURATION_MI", Math.round(parseFloat($v("P11_DURATION"))/60));'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(22167419846368437)
,p_name=>'directions'
,p_event_sequence=>50
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(32938967914408721)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|directions'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(22167567796368438)
,p_event_id=>wwv_flow_api.id(22167419846368437)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$s("P11_DISTANCE",this.data.distance);',
'$s("P11_DURATION",this.data.duration);',
'$s("P11_LEGS",this.data.legs);'))
);
wwv_flow_api.component_end;
end;
/
