prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>15181
,p_default_id_offset=>0
,p_default_owner=>'JK64'
);
wwv_flow_api.create_page(
 p_id=>6
,p_user_interface_id=>wwv_flow_api.id(25186303948932505463)
,p_name=>'Geo Heatmap'
,p_alias=>'HEATMAP'
,p_step_title=>'Geo Heatmap'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>This map renders the data as a Heatmap.</strong>',
'<p>',
'Query for map plugin:',
'<code>',
'    select round(lat,3), round(lng,3), sum(10*(mag+1))',
'    from jk64demo_earthquakes',
'    where mag+1>=0',
'    group by round(lat,3), round(lng,3)',
'</code>',
'<p>',
'Adding the SUM() and GROUP BY helps to reduce the volume of data sent to the client. For a heatmap, sending 5 rows with the same position and weight "1" is the same as sending a single row with weight "5".'))
,p_page_comment=>'This page requires the table jk64demo_earthquakes.'
,p_last_updated_by=>'JEFF'
,p_last_upd_yyyymmddhh24miss=>'20200520083038'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(86703429402923302)
,p_plug_name=>'column1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(25186269690704505415)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(138044127907793320)
,p_plug_name=>'Geo Heatmap'
,p_parent_plug_id=>wwv_flow_api.id(86703429402923302)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(25186277719855505424)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_HELP_TEXT'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(3279010546482362500)
,p_plug_name=>'Report Google Map Plugin ("mymap")'
,p_region_name=>'mymap'
,p_parent_plug_id=>wwv_flow_api.id(86703429402923302)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(25186269690704505415)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>'select round(lat,3), round(lng,3), sum(exp(mag+1)) from jk64demo_earthquakes where mag+1>=0 group by round(lat,3), round(lng,3)'
,p_plug_source_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'400'
,p_attribute_02=>'HEATMAP'
,p_attribute_03=>'13'
,p_attribute_04=>'PAN_ON_CLICK:PAN_ALLOWED:ZOOM_ALLOWED:SPINNER'
,p_attribute_11=>'[{"featureType":"water","elementType":"geometry","stylers":[{"color":"#e9e9e9"},{"lightness":17}]},{"featureType":"landscape","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":20}]},{"featureType":"road.highway","elementType":"geom'
||'etry.fill","stylers":[{"color":"#ffffff"},{"lightness":17}]},{"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#ffffff"},{"lightness":29},{"weight":0.2}]},{"featureType":"road.arterial","elementType":"geometry","style'
||'rs":[{"color":"#ffffff"},{"lightness":18}]},{"featureType":"road.local","elementType":"geometry","stylers":[{"color":"#ffffff"},{"lightness":16}]},{"featureType":"poi","elementType":"geometry","stylers":[{"color":"#f5f5f5"},{"lightness":21}]},{"featu'
||'reType":"poi.park","elementType":"geometry","stylers":[{"color":"#dedede"},{"lightness":21}]},{"elementType":"labels.text.stroke","stylers":[{"visibility":"on"},{"color":"#ffffff"},{"lightness":16}]},{"elementType":"labels.text.fill","stylers":[{"sat'
||'uration":36},{"color":"#333333"},{"lightness":40}]},{"elementType":"labels.icon","stylers":[{"visibility":"off"}]},{"featureType":"transit","elementType":"geometry","stylers":[{"color":"#f2f2f2"},{"lightness":19}]},{"featureType":"administrative","el'
||'ementType":"geometry.fill","stylers":[{"color":"#fefefe"},{"lightness":20}]},{"featureType":"administrative","elementType":"geometry.stroke","stylers":[{"color":"#fefefe"},{"lightness":17},{"weight":1.2}]}]'
,p_attribute_12=>'N'
,p_attribute_13=>'0.7'
,p_attribute_14=>'10'
,p_attribute_21=>'N'
,p_attribute_22=>'ROADMAP'
,p_attribute_24=>'Y'
,p_attribute_25=>'auto'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(3279010742957362502)
,p_name=>'Source data'
,p_template=>wwv_flow_api.id(25186277719855505424)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_grid_column_span=>3
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>'select round(lat,3), round(lng,3), sum(10*(mag+1)) from jk64demo_earthquakes where mag+1>=0 group by round(lat,3), round(lng,3)'
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(25186286576607505432)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(33393896629218438)
,p_query_column_id=>1
,p_column_alias=>'ROUND(LAT,3)'
,p_column_display_sequence=>1
,p_column_heading=>'Round(lat,3)'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(33393924751218439)
,p_query_column_id=>2
,p_column_alias=>'ROUND(LNG,3)'
,p_column_display_sequence=>2
,p_column_heading=>'Round(lng,3)'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(33394094415218440)
,p_query_column_id=>3
,p_column_alias=>'SUM(10*(MAG+1))'
,p_column_display_sequence=>3
,p_column_heading=>'Sum(10*(mag+1))'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.component_end;
end;
/
