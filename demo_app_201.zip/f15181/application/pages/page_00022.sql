prompt --application/pages/page_00022
begin
--   Manifest
--     PAGE: 00022
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>15181
,p_default_id_offset=>0
,p_default_owner=>'JK64'
);
wwv_flow_api.create_page(
 p_id=>22
,p_user_interface_id=>wwv_flow_api.id(25186303948932505463)
,p_name=>'Load GeoJSON from database'
,p_alias=>'GEOJSON'
,p_step_title=>'Load GeoJSON from database'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'To load GeoJSON onto the map programmatically, the following Javascript API call can be used:',
'<code>',
'$("#map_testmap").reportmap("loadGeoJsonString", ''...your geoJON here...'');',
'</code>',
'<p>',
'<hr>',
'Alternatively, you can load GeoJSON onto the map via the SQL Query.'))
,p_page_comment=>'This page requires the table jk64demo_countries.'
,p_last_updated_by=>'JEFF'
,p_last_upd_yyyymmddhh24miss=>'20200520091053'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(53976929483556324)
,p_plug_name=>'Geometry Data Not Loaded'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning'
,p_plug_template=>wwv_flow_api.id(25186268102268505408)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'This page requires the country border geometry loaded into the jk64demo_countries table.',
'<p>',
'To load this data, run <code>jk64demo_countries_geometry.sql</code>. You can download this script from <a href="https://github.com/jeffreykemp/jk64-plugin-reportmap/tree/master/demo_src" target=_blank>here</a>.'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NOT_EXISTS'
,p_plug_display_when_condition=>'select 1 from jk64demo_countries where geometry is not null'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(143264965385881192)
,p_plug_name=>'Info'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(25186277719855505424)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_HELP_TEXT'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(231578645525892407)
,p_plug_name=>'Load GeoJSON from database'
,p_region_name=>'testmap'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(25186277719855505424)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'400'
,p_attribute_02=>'PINS'
,p_attribute_04=>'PAN_ON_CLICK:DRAGGABLE:PAN_ALLOWED:ZOOM_ALLOWED:SPINNER'
,p_attribute_12=>'N'
,p_attribute_21=>'N'
,p_attribute_22=>'ROADMAP'
,p_attribute_24=>'Y'
,p_attribute_25=>'greedy'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(23769800678459439)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(231578645525892407)
,p_button_name=>'DELETE_ALL_FEATURES'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(25186298792612505445)
,p_button_image_alt=>'Delete All Features'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(53977299144556327)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(143264965385881192)
,p_button_name=>'GEOJSON_VISUALISATION'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(25186298860096505445)
,p_button_image_alt=>'Load GeoJson via SQL'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.:RP::'
,p_icon_css_classes=>'fa-radar-chart'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(23770144837459442)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(231578645525892407)
,p_button_name=>'LOAD_ALL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(25186298792612505445)
,p_button_image_alt=>'Load All'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(50331505725390985)
,p_name=>'P22_COUNTRY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(231578645525892407)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Country'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select country || '' ('' || ceil(dbms_lob.getlength(geometry)/1024) || ''KB)'' as d',
'      ,country',
'from jk64demo_countries',
'where geometry is not null',
'and country != ''Antarctica''',
'order by country'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(25186298275602505444)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(50331917207390988)
,p_name=>'P22_GEOJSON'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(231578645525892407)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(50332385997391004)
,p_name=>'set polygon hole mode'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P22_POLYGON_HOLE'
,p_condition_element=>'P22_POLYGON_HOLE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'POLYGON_HOLE'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(50332879137391006)
,p_event_id=>wwv_flow_api.id(50332385997391004)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#map_testmap").reportmap({"drawingPolygonHole":false});'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(50333390663391007)
,p_event_id=>wwv_flow_api.id(50332385997391004)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#map_testmap").reportmap({"drawingPolygonHole":true});'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(50333769817391007)
,p_name=>'load sample'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(42643768439606715)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(50334207073391007)
,p_event_id=>wwv_flow_api.id(50333769817391007)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#map_testmap").reportmap("loadGeoJsonString", ''{"type":"FeatureCollection","features":[{"type":"Feature","geometry":{"type":"Polygon","coordinates":[[[115.81810956058052,-31.97383444279713],[115.81816320476082,-31.965348125709053],[115.81942705955'
||'316,-31.963045289361652],[115.83356551761699,-31.950765554651483],[115.84524707746186,-31.954567079185118],[115.84569017891499,-31.959739299429998],[115.8460045343354,-31.961616227489593],[115.8422644610373,-31.963072596059856],[115.84141044463922,-3'
||'1.964019223244122],[115.84023992757739,-31.964798362690065],[115.83827547664714,-31.967871166607786],[115.83664147701074,-31.96930650292521],[115.83428864535836,-31.970050102393433],[115.83351831178607,-31.971133179223234],[115.83172337698943,-31.972'
||'00873460981],[115.8272462331779,-31.97259304090624],[115.82645659503487,-31.97074727635052],[115.82297186593951,-31.97255845111874],[115.81810956058052,-31.97383444279713]],[[115.82864956807771,-31.962373541584306],[115.83208279561677,-31.96448525105'
||'9358],[115.83534436177888,-31.962373541584306],[115.83534436177888,-31.957567401061706],[115.83208279561677,-31.959351528034734],[115.82847790670075,-31.957640223249268],[115.82864956807771,-31.962373541584306]]]}}]}'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(50334670966391008)
,p_name=>'load country borders'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P22_COUNTRY'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(50335132619391008)
,p_event_id=>wwv_flow_api.id(50334670966391008)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_APEX.CLOB.LOAD.2'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select /* Element type dom - for jQuery selector e.g. body or #region-id, item - for item name e.g. P1_MY_ITEM */',
'    ''item'' AS ELEMENT_TYPE,',
'    /* jQuery selector or item name */',
'    ''P22_GEOJSON'' AS ELEMENT_SELECTOR,',
'    geometry as clob_value',
'from jk64demo_countries',
'where country = :P22_COUNTRY'))
,p_attribute_02=>'P22_COUNTRY'
,p_attribute_03=>'N'
,p_attribute_04=>'PRINT_CLOB'
,p_attribute_05=>'Y'
,p_attribute_10=>'N'
,p_attribute_13=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(23769977703459440)
,p_name=>'on click delete all features'
,p_event_sequence=>130
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(23769800678459439)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(23770065299459441)
,p_event_id=>wwv_flow_api.id(23769977703459440)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#map_testmap").reportmap("deleteAllFeatures");'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(23770267752459443)
,p_name=>'on click load all'
,p_event_sequence=>140
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(23770144837459442)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(23770715618459448)
,p_event_id=>wwv_flow_api.id(23770267752459443)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_APEX.CLOB.LOAD.2'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(231578645525892407)
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select /* Element type dom - for jQuery selector e.g. body or #region-id, item - for item name e.g. P1_MY_ITEM */',
'    ''item'' AS ELEMENT_TYPE,',
'    /* jQuery selector or item name */',
'    ''P22_GEOJSON'' AS ELEMENT_SELECTOR,',
'    geometry as clob_value',
'from jk64demo_countries',
'where country != ''Antarctica''',
'and geometry is not null'))
,p_attribute_03=>'N'
,p_attribute_04=>'PRINT_CLOB'
,p_attribute_05=>'Y'
,p_attribute_10=>'N'
,p_attribute_13=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(23770479354459445)
,p_name=>'on load geojson'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P22_GEOJSON'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(23770555888459446)
,p_event_id=>wwv_flow_api.id(23770479354459445)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v("P22_GEOJSON")) {',
'  $("#map_testmap").reportmap("loadGeoJsonString", ',
'    ''{"type":"Feature","geometry":''+$v("P22_GEOJSON")+''}'');',
'}'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(53976611174556321)
,p_name=>'double click geojson'
,p_event_sequence=>160
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P22_GEOJSON'
,p_bind_type=>'bind'
,p_bind_event_type=>'dblclick'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(53976737025556322)
,p_event_id=>wwv_flow_api.id(53976611174556321)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v("P22_GEOJSON")) {',
'  $("#map_testmap").reportmap("loadGeoJsonString", ',
'    ''{"type":"Feature","geometry":''+$v("P22_GEOJSON")+''}'');',
'}'))
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(53976868867556323)
,p_event_id=>wwv_flow_api.id(53976611174556321)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P22_GEOJSON'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_api.component_end;
end;
/
