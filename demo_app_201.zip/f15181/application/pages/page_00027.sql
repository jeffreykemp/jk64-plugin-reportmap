prompt --application/pages/page_00027
begin
--   Manifest
--     PAGE: 00027
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>15181
,p_default_id_offset=>0
,p_default_owner=>'JK64'
);
wwv_flow_api.create_page(
 p_id=>27
,p_user_interface_id=>wwv_flow_api.id(25186303948932505463)
,p_name=>'Load GeoJSON via SQL'
,p_alias=>'SQLGEOJSON'
,p_step_title=>'Load GeoJSON via SQL'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'The Visualisation on this map is set to "GeoJson" and the SQL Query loads 10 countries selected at random.',
'<p>',
'<code>',
'select json_object(',
'           ''type'' is ''Feature'',',
'           ''geometry'' is geometry',
'           returning clob',
'       ) as geojson',
'      ,country as name',
'      ,rownum as id',
'      ,country||''-flex1'' as flex1',
'      ,country||''-flex2'' as flex2',
'from (',
'    select * ',
'    from   jk64demo_countries',
'    where  geometry is not null',
'    order by dbms_random.value',
') where rownum <= 10',
'</code>',
'<p>',
'<hr>',
'Alternatively, a similar outcome could have been produced by embedding the',
'properties in the geoJson document; this allows the developer to include any',
'arbitrary properties while avoiding using "flex" fields:',
'<code>',
'select json_object(',
'           ''type'' is ''Feature'',',
'           ''geometry'' is c.geometry,',
'           ''properties'' is json_object(',
'               ''id'' is c.id,',
'               ''name'' is c.country,',
'               ''population'' is c.pop',
'           )',
'           returning clob',
'       ) as geojson',
'from   country_borders c',
'</code>',
'<hr>',
'A Dynamic Action on the <b>mouseoverFeature</b> event sets <code>P27_NAME</code> to:',
'<code>',
'this.data.feature.getProperty("name")',
'</code>',
'A Dynamic Action on the <b>mouseoutFeature</b> event clears <code>P27_NAME</code>.',
'<hr>',
'A Dynamic Action on the <b>selectFeature</b> event sets <code>P27_DATA</code> to:',
'<code>',
'"id=" + this.data.feature.getProperty("id")',
'+ " attr01=" + this.data.feature.getProperty("attr01")',
'+ " attr02=" + this.data.feature.getProperty("attr02")',
'</code>',
'<hr>',
'Refresh the page to load the borders for a different set of countries.',
'<hr>',
'It is possible to query the data layer and interact dynamically with its contents.',
'For example, the "Select feature with id=1" button runs the following JavaScript:',
'<p>',
'<code>',
'var dataLayer = $("#map_testmap").reportmap("instance").map.data,',
'    feature = dataLayer.getFeatureById(''1'');',
'',
'feature.setProperty("isSelected",true);',
'',
'$s("P27_NAME", feature.getProperty("name"));',
'',
'$s("P27_DETAILS",',
'    "id=" + feature.getProperty("id")',
'    + " attr01=" + feature.getProperty("attr01")',
'    + " attr02=" + feature.getProperty("attr02"));',
'</code>',
'<p>',
'This gets the Data Layer from the Google Map object, then queries it for the',
'feature matching the given ID (note that our query sets id to the rownum). It',
'then sets the "isSelected" property on the feature which triggers the map to',
're-execute the feature''s style function.',
'<hr>',
'Just for fun, the <b>Draggable</b> plugin option has been set.',
'<p>',
'A custom style hides all the labels and roads from the map.'))
,p_page_comment=>'This page requires the table jk64demo_countries.'
,p_last_updated_by=>'JEFF'
,p_last_upd_yyyymmddhh24miss=>'20200520091135'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(108624573787901255)
,p_plug_name=>'Geometry Data Not Loaded'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning'
,p_plug_template=>wwv_flow_api.id(25186268102268505408)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'This page requires the country border geometry loaded into the jk64demo_countries table.',
'<p>',
'To load this data, run <code>jk64demo_countries_geometry.sql</code>. You can download this script from <a href="https://github.com/jeffreykemp/jk64-plugin-reportmap/tree/master/demo_src" target=_blank>here</a>.'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NOT_EXISTS'
,p_plug_display_when_condition=>'select 1 from jk64demo_countries where geometry is not null'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(197912609690226123)
,p_plug_name=>'Info'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(25186277719855505424)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_HELP_TEXT'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(286226289830237338)
,p_plug_name=>'Load GeoJSON via SQL'
,p_region_name=>'testmap'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(25186277719855505424)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select json_object(',
'           ''type'' is ''Feature'',',
'           ''geometry'' is geometry',
'           returning clob',
'       ) as geojson',
'      ,country as name',
'      ,rownum as id',
'      ,country||''-flex1'' as flex1',
'      ,country||''-flex2'' as flex2',
'from (',
'    select * ',
'    from   jk64demo_countries',
'    where  country != ''Antarctica''',
'    and    geometry is not null',
'    order by dbms_random.value',
') where rownum <= 10'))
,p_plug_source_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'400'
,p_attribute_02=>'GEOJSON'
,p_attribute_04=>'PAN_ON_CLICK:DRAGGABLE:PAN_ALLOWED:ZOOM_ALLOWED:SPINNER'
,p_attribute_11=>wwv_flow_string.join(wwv_flow_t_varchar2(
'[',
'    {',
'        "featureType": "all",',
'        "elementType": "labels",',
'        "stylers": [',
'            {',
'                "visibility": "off"',
'            }',
'        ]',
'    },',
'    {',
'        "featureType": "road",',
'        "elementType": "all",',
'        "stylers": [',
'            {',
'                "visibility": "off"',
'            }',
'        ]',
'    },',
'    {',
'        "featureType": "transit",',
'        "elementType": "all",',
'        "stylers": [',
'            {',
'                "visibility": "off"',
'            }',
'        ]',
'    }',
']'))
,p_attribute_12=>'N'
,p_attribute_21=>'N'
,p_attribute_22=>'ROADMAP'
,p_attribute_24=>'Y'
,p_attribute_25=>'greedy'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(53978495913556339)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(286226289830237338)
,p_button_name=>'SELECT1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(25186298792612505445)
,p_button_image_alt=>'Select feature with id=1'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(53977893245556333)
,p_name=>'P27_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(286226289830237338)
,p_prompt=>'Country:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>4
,p_field_template=>wwv_flow_api.id(25186298275602505444)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(53978171492556336)
,p_name=>'P27_DETAILS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(286226289830237338)
,p_prompt=>'Data:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(25186298275602505444)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(54650401955344995)
,p_name=>'set polygon hole mode'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P27_POLYGON_HOLE'
,p_condition_element=>'P27_POLYGON_HOLE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'POLYGON_HOLE'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(54650985645344998)
,p_event_id=>wwv_flow_api.id(54650401955344995)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#map_testmap").reportmap({"drawingPolygonHole":false});'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(54651444201344998)
,p_event_id=>wwv_flow_api.id(54650401955344995)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#map_testmap").reportmap({"drawingPolygonHole":true});'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(54651878513344998)
,p_name=>'load sample'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(42643768439606715)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(54652358887344999)
,p_event_id=>wwv_flow_api.id(54651878513344998)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#map_testmap").reportmap("loadGeoJsonString", ''{"type":"FeatureCollection","features":[{"type":"Feature","geometry":{"type":"Polygon","coordinates":[[[115.81810956058052,-31.97383444279713],[115.81816320476082,-31.965348125709053],[115.81942705955'
||'316,-31.963045289361652],[115.83356551761699,-31.950765554651483],[115.84524707746186,-31.954567079185118],[115.84569017891499,-31.959739299429998],[115.8460045343354,-31.961616227489593],[115.8422644610373,-31.963072596059856],[115.84141044463922,-3'
||'1.964019223244122],[115.84023992757739,-31.964798362690065],[115.83827547664714,-31.967871166607786],[115.83664147701074,-31.96930650292521],[115.83428864535836,-31.970050102393433],[115.83351831178607,-31.971133179223234],[115.83172337698943,-31.972'
||'00873460981],[115.8272462331779,-31.97259304090624],[115.82645659503487,-31.97074727635052],[115.82297186593951,-31.97255845111874],[115.81810956058052,-31.97383444279713]],[[115.82864956807771,-31.962373541584306],[115.83208279561677,-31.96448525105'
||'9358],[115.83534436177888,-31.962373541584306],[115.83534436177888,-31.957567401061706],[115.83208279561677,-31.959351528034734],[115.82847790670075,-31.957640223249268],[115.82864956807771,-31.962373541584306]]]}}]}'');'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(54652784298344999)
,p_name=>'load country borders'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P27_COUNTRY'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(54653234105345000)
,p_event_id=>wwv_flow_api.id(54652784298344999)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_APEX.CLOB.LOAD.2'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select /* Element type dom - for jQuery selector e.g. body or #region-id, item - for item name e.g. P1_MY_ITEM */',
'    ''item'' AS ELEMENT_TYPE,',
'    /* jQuery selector or item name */',
'    ''P27_GEOJSON'' AS ELEMENT_SELECTOR,',
'    geometry as clob_value',
'from jk64demo_countries',
'where country = :P27_COUNTRY'))
,p_attribute_02=>'P27_COUNTRY'
,p_attribute_03=>'N'
,p_attribute_04=>'PRINT_CLOB'
,p_attribute_05=>'Y'
,p_attribute_10=>'N'
,p_attribute_13=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(54656868798345002)
,p_name=>'on load geojson'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P27_GEOJSON'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(54657393083345002)
,p_event_id=>wwv_flow_api.id(54656868798345002)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v("P27_GEOJSON")) {',
'  $("#map_testmap").reportmap("loadGeoJsonString", ',
'    ''{"type":"Feature","geometry":''+$v("P27_GEOJSON")+''}'');',
'}'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(54655450519345001)
,p_name=>'on load geojson_1'
,p_event_sequence=>160
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P27_GEOJSON'
,p_bind_type=>'bind'
,p_bind_event_type=>'dblclick'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(54655925961345001)
,p_event_id=>wwv_flow_api.id(54655450519345001)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v("P27_GEOJSON")) {',
'  $("#map_testmap").reportmap("loadGeoJsonString", ',
'    ''{"type":"Feature","geometry":''+$v("P27_GEOJSON")+''}'');',
'}'))
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(54656484660345002)
,p_event_id=>wwv_flow_api.id(54655450519345001)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P27_GEOJSON'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(53977696811556331)
,p_name=>'mouse over feature'
,p_event_sequence=>170
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(286226289830237338)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|mouseoverfeature'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(53977715751556332)
,p_event_id=>wwv_flow_api.id(53977696811556331)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P27_NAME'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.data.feature.getProperty("name")'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(53977932904556334)
,p_name=>'mouse out feature'
,p_event_sequence=>180
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(286226289830237338)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|mouseoutfeature'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(53978039883556335)
,p_event_id=>wwv_flow_api.id(53977932904556334)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P27_NAME'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(53978242087556337)
,p_name=>'select feature'
,p_event_sequence=>190
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(286226289830237338)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|selectfeature'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(53978388864556338)
,p_event_id=>wwv_flow_api.id(53978242087556337)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P27_DETAILS'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>wwv_flow_string.join(wwv_flow_t_varchar2(
'"id=" + this.data.feature.getProperty("id")',
'    + " attr01=" + this.data.feature.getProperty("attr01")',
'    + " attr02=" + this.data.feature.getProperty("attr02")'))
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(53978555069556340)
,p_name=>'on click select 1'
,p_event_sequence=>200
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(53978495913556339)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(53978666591556341)
,p_event_id=>wwv_flow_api.id(53978555069556340)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var dataLayer = $("#map_testmap").reportmap("instance").map.data,',
'    feature = dataLayer.getFeatureById(''1'');',
'',
'feature.setProperty("isSelected",true);',
'',
'$s("P27_NAME", feature.getProperty("name"));',
'',
'$s("P27_DETAILS",',
'    "id=" + feature.getProperty("id")',
'    + " attr01=" + feature.getProperty("attr01")',
'    + " attr02=" + feature.getProperty("attr02"));'))
);
wwv_flow_api.component_end;
end;
/
