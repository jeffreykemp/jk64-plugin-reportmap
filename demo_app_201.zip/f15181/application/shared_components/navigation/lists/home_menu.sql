prompt --application/shared_components/navigation/lists/home_menu
begin
--   Manifest
--     LIST: Home Menu
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>15181
,p_default_id_offset=>0
,p_default_owner=>'JK64'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(33313102857679622)
,p_name=>'Home Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33317727701679625)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Report Pins'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-map-marker'
,p_list_text_01=>'Show a set of data as pins on the map.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'1'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33318579089679626)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Marker Clustering'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-plus-circle'
,p_list_text_01=>'When many pins are very close together, dynamically cluster them into a single marker showing the number of pins within it.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'4'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33318197632679626)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Route Map'
,p_list_item_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-car'
,p_list_text_01=>'Show route directions between two points with up to 8 waypoints on the way.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'11'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33317303234679625)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Directions'
,p_list_item_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-map-signs'
,p_list_text_01=>'Allow the end user to ask for directions from one location to another.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'7'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33318917524679626)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Geo Heatmap'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-globe'
,p_list_text_01=>'Render a large number of data points as a geographic heatmap.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'6'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(53917148155038029)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Spiderfier'
,p_list_item_link_target=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-asterisk'
,p_list_text_01=>'Visualisation that helps show pins that are very close or overlapping.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33333579395703125)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Multiple Map Regions'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-clone'
,p_list_text_01=>'Demonstrates how multiple instances of the map plugin can be rendered on the page, and how each can be manipulated independently.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33315320628679624)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Pin Labels'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tag'
,p_list_text_01=>'Show a letter as a label on each pin.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'10'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33315735448679624)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Pin Icons'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-plane'
,p_list_text_01=>'Use an alternative image for the pins. Icons are loaded from a URL. Each data point may have a different icon.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'8'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33316179167679625)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Static Icons'
,p_list_item_link_target=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-image-o'
,p_list_text_01=>'Load icons for the markers loaded as Static Application Files in the APEX application.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'16'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33316544762679625)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Search Map'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-search'
,p_list_text_01=>'Allow the user to search the map for an address or location name.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'5'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33316954704679625)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Geolocate'
,p_list_item_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bolt'
,p_list_text_01=>'Find the user''s device location on the map.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'12'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33319340798679626)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Sync with Report'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-refresh'
,p_list_text_01=>'Have a link in a report that, when clicked, pans to a pin on the map and shows its info window.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'3'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33319768039679627)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Draggable Pins'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-arrows-alt'
,p_list_text_01=>'Allow the end user to drag pins to new locations on the map.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'2'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33320106676679627)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Disabled Pan / Zoom'
,p_list_item_link_target=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-ban'
,p_list_text_01=>'Make the map "static" - i.e. so the user cannot zoom or pan.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'14'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33320521084679627)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>'Javascript Initialization'
,p_list_item_link_target=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-code'
,p_list_text_01=>'Add your own JavaScript code to perform customisations, e.g. using the Google Maps JavaScript API.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'13'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33431831826571525)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>'Flex Fields'
,p_list_item_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-database'
,p_list_text_01=>'Associate "flex fields" with extra data with each pin on the map.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(34089085421399527)
,p_list_item_display_sequence=>180
,p_list_item_link_text=>'Map Layers'
,p_list_item_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layers'
,p_list_text_01=>'Show a Google Maps Layer (Traffic, Transit, or Bicycling)'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(44679507564672602)
,p_list_item_display_sequence=>190
,p_list_item_link_text=>'Drawing & GeoJSON'
,p_list_item_link_target=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-pencil-square-o'
,p_list_text_01=>'Draw shapes (polygons) onto the map. Drag-and-drop GeoJSON files onto the map. Export features as a GeoJSON document.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(48459571914205681)
,p_list_item_display_sequence=>200
,p_list_item_link_text=>'Event: Marker Added'
,p_list_item_link_target=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-trigger'
,p_list_text_01=>'Add custom behaviour when pins are added to the map.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(53873507840602053)
,p_list_item_display_sequence=>210
,p_list_item_link_text=>'Localisation'
,p_list_item_link_target=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-language'
,p_list_text_01=>'Override the user''s preferred language, and/or bias geocode results (searching by address) to a particular region.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(54160472022773206)
,p_list_item_display_sequence=>220
,p_list_item_link_text=>'Custom Marker Formatting'
,p_list_item_link_target=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-design'
,p_list_text_01=>'Provide a javascript function to format or manipulate each marker with whatever logic you need.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(54219023471494855)
,p_list_item_display_sequence=>230
,p_list_item_link_text=>'Batched Results'
,p_list_item_link_target=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-hourglass-2'
,p_list_text_01=>'Load a large number of pin data in batches, via multiple ajax calls.'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
