prompt --application/shared_components/navigation/lists/desktop_navigation_menu
begin
--   Manifest
--     LIST: Desktop Navigation Menu
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>15181
,p_default_id_offset=>0
,p_default_owner=>'JK64'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(25186261540139505399)
,p_name=>'Desktop Navigation Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(108544596526040817)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Demo Home'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33281403869456829)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Visualisations'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-eye'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(25186305489555505552)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Report Pins'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-map-marker'
,p_parent_list_item_id=>wwv_flow_api.id(33281403869456829)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(110569494406744322)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>'Route Map'
,p_list_item_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-car'
,p_parent_list_item_id=>wwv_flow_api.id(33281403869456829)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32259407852619167)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>'Marker Clustering'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-plus-circle'
,p_parent_list_item_id=>wwv_flow_api.id(33281403869456829)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(53909164196992001)
,p_list_item_display_sequence=>180
,p_list_item_link_text=>'Spiderfier'
,p_list_item_link_target=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-asterisk'
,p_parent_list_item_id=>wwv_flow_api.id(33281403869456829)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'24'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32277839462935717)
,p_list_item_display_sequence=>190
,p_list_item_link_text=>'Geo Heatmap'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-globe'
,p_parent_list_item_id=>wwv_flow_api.id(33281403869456829)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(54683545433658850)
,p_list_item_display_sequence=>200
,p_list_item_link_text=>'GeoJSON'
,p_list_item_link_target=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-radar-chart'
,p_parent_list_item_id=>wwv_flow_api.id(33281403869456829)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'27'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33274013504426442)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Marker Styling'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-map-marker'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(109890937937436544)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Pin Labels'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tag'
,p_parent_list_item_id=>wwv_flow_api.id(33274013504426442)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33244910302972029)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Pin Icons'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-plane'
,p_parent_list_item_id=>wwv_flow_api.id(33274013504426442)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33265093806320112)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Static Icons'
,p_list_item_link_target=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-image-o'
,p_parent_list_item_id=>wwv_flow_api.id(33274013504426442)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(54145802687283308)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Custom'
,p_list_item_link_target=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-design'
,p_parent_list_item_id=>wwv_flow_api.id(33274013504426442)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'25'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33280578924449447)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Geocoding'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-compass'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(75545709693123640)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Search Map'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-search'
,p_parent_list_item_id=>wwv_flow_api.id(33280578924449447)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(137056019713145863)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Geolocate'
,p_list_item_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bolt'
,p_parent_list_item_id=>wwv_flow_api.id(33280578924449447)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(82100728880548355)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Directions'
,p_list_item_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-map-signs'
,p_parent_list_item_id=>wwv_flow_api.id(33280578924449447)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33282510915468298)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Custom Behaviour'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-gears'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(75088489437959564)
,p_list_item_display_sequence=>210
,p_list_item_link_text=>'Sync with Report'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-refresh'
,p_parent_list_item_id=>wwv_flow_api.id(33282510915468298)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32239493111468704)
,p_list_item_display_sequence=>220
,p_list_item_link_text=>'Draggable Pins'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-arrows-alt'
,p_parent_list_item_id=>wwv_flow_api.id(33282510915468298)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32918794694333288)
,p_list_item_display_sequence=>230
,p_list_item_link_text=>'Disabled Pan / Zoom'
,p_list_item_link_target=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-ban'
,p_parent_list_item_id=>wwv_flow_api.id(33282510915468298)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32700598309779864)
,p_list_item_display_sequence=>240
,p_list_item_link_text=>'Javascript Initialization'
,p_list_item_link_target=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-code'
,p_parent_list_item_id=>wwv_flow_api.id(33282510915468298)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33385686175209543)
,p_list_item_display_sequence=>250
,p_list_item_link_text=>'Flex Fields'
,p_list_item_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-database'
,p_parent_list_item_id=>wwv_flow_api.id(33282510915468298)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(34001707422955107)
,p_list_item_display_sequence=>260
,p_list_item_link_text=>'Map Layers'
,p_list_item_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layers'
,p_parent_list_item_id=>wwv_flow_api.id(33282510915468298)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(48397319460597037)
,p_list_item_display_sequence=>270
,p_list_item_link_text=>'Event: Marker Added'
,p_list_item_link_target=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-trigger'
,p_parent_list_item_id=>wwv_flow_api.id(33282510915468298)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'20'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(54218766907484464)
,p_list_item_display_sequence=>280
,p_list_item_link_text=>'Batched Results'
,p_list_item_link_target=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-hourglass-2'
,p_parent_list_item_id=>wwv_flow_api.id(33282510915468298)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(53811131567280288)
,p_list_item_display_sequence=>290
,p_list_item_link_text=>'Localisation'
,p_list_item_link_target=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-language'
,p_parent_list_item_id=>wwv_flow_api.id(33282510915468298)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'21'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(44669180677691156)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Drawing & GeoJSON'
,p_list_item_link_target=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-pencil-square-o'
,p_list_text_01=>'Draw shapes (polygons) onto the map. Drag-and-drop GeoJSON files onto the map. Export features as a GeoJSON document.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'19'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(50290600439883548)
,p_list_item_display_sequence=>300
,p_list_item_link_text=>'Load GeoJSON via JavaScript'
,p_list_item_link_target=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(44669180677691156)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'22'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32930148968395655)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'A Tale of Two Cities'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-clone'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
