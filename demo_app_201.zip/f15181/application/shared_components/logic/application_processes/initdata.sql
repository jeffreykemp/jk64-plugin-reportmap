prompt --application/shared_components/logic/application_processes/initdata
begin
--   Manifest
--     APPLICATION PROCESS: INITDATA
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>15181
,p_default_id_offset=>0
,p_default_owner=>'JK64'
);
wwv_flow_api.create_flow_process(
 p_id=>wwv_flow_api.id(75112338222146653)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'INITDATA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  id number := 0;',
'  icon_arr apex_t_varchar2;',
'',
'  procedure m (name in varchar2, lat in number, lng in number, pop in number) is',
'    i number;',
'    arr_index number;',
'  begin',
'    id := id + 1;',
'    arr_index := ((id-1) mod icon_arr.count)+1;',
'    if arr_index not between 1 and icon_arr.count then',
'        raise_application_error(-20000, ''i=''||i||'' count=''||icon_arr.count||'' idx=''||arr_index);',
'    end if;',
'    select ora_hash(name,2) into i from dual;',
'    apex_collection.add_member',
'      (''MAP''',
'      ,p_c001 => to_char(id)',
'      ,p_c002 => name',
'      ,p_c003 => to_char(lat,''fm990.099999'')',
'      ,p_c004 => to_char(lng,''fm990.099999'')',
'      ,p_c005 => to_char(pop,''fm9990.099999'')',
'      ,p_c006 => dbms_random.string(''a'',10)',
'      ,p_c007 => case i',
'                 when 0 then ''parking_lot_maps.png''',
'                 when 1 then ''library_maps.png''',
'                 when 2 then ''info-i_maps.png''',
'                 end',
'      ,p_c008 => icon_arr(arr_index)',
'      ,p_c009 => dbms_random.string(''a'',3)',
'      ,p_c010 => dbms_random.string(''a'',3)',
'      ,p_c011 => dbms_random.string(''a'',3)',
'      );',
'  end m;',
'',
'begin',
'',
'    select file_name',
'    bulk collect into icon_arr',
'    from apex_application_static_files',
'    where file_name like ''icon/%'';',
'    ',
'    if icon_arr.count = 0 then',
'        raise_application_error(-20000,''no icons found'');',
'    end if;',
'',
'    apex_collection.create_or_truncate_collection(''MAP'');',
'',
'    m(''home'',-32.116202,116.065471,null);',
'    m(''Stratton'',-31.869722,116.034851,40);',
'    m(''Wyalkatchem'',-31.181378,117.380332,20);',
'    m(''boss''''s office'',-31.958206,115.864348,120);',
'    m(''Wattle Grove'',-32.013843,116.001141,32);',
'    m(''Rottnest Island'',-31.998759,115.538063,5);',
'    m(''Busselton'',-33.645277,115.342540,19);',
'    m(''Esperance'',-33.852597,121.897087,21);',
'    m(''Carnarvon'',-24.884879,113.656654,14);',
'    m(''Cable Beach'',-17.960934,122.212257,9);',
'    m(''Hillarys Boat Harbour'',-31.824755,115.739808,33);',
'    m(''Wave Rock'',-32.441371,118.897390,8.5);',
'    m(''Araluen Botanical Park'',-32.123472,116.101037,2.4);',
'    m(''Null Island'',0,0,2000);',
'',
'end;'))
,p_process_when=>'NOT APEX_COLLECTION.collection_exists(''MAP'')'
,p_process_when_type=>'PLSQL_EXPRESSION'
);
wwv_flow_api.component_end;
end;
/
