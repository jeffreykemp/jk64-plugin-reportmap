prompt --application/shared_components/logic/application_processes/initdata2
begin
--   Manifest
--     APPLICATION PROCESS: INITDATA2
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>22940
,p_default_id_offset=>32959023425505623190
,p_default_owner=>'JK64'
);
wwv_flow_api.create_flow_process(
 p_id=>wwv_flow_api.id(33069592218198357350)
,p_process_sequence=>1
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'INITDATA2'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  id NUMBER := 0;',
'  PROCEDURE m (name IN VARCHAR2, lat IN NUMBER, lng IN NUMBER, pop IN NUMBER) IS',
'  BEGIN',
'    id := id + 1;',
'    APEX_COLLECTION.add_member',
'      (''ROUTE''',
'      ,TO_CHAR(id)',
'      ,name',
'      ,TO_CHAR(lat,''fm999.9999999999999999'')',
'      ,TO_CHAR(lng,''fm999.9999999999999999'')',
'      ,TO_CHAR(pop,''fm999999999999.9999999999999999'')',
'      ,dbms_random.string(''a'',10));',
'  END m;',
'BEGIN',
'APEX_COLLECTION.create_or_truncate_collection(''ROUTE'');',
'm(''Stratton'',-31.86972210984067,116.03485107421875,40);',
'm(''Perth'',-31.958206638801293,115.86434841156006,120);',
'm(''Hillarys Boat Harbour'',-31.82475514059112,115.73980808258057,33);',
'm(''Araluen Botanical Park'',-32.12347204914411,116.10103726387024,2.4);',
'END;'))
);
wwv_flow_api.component_end;
end;
/
