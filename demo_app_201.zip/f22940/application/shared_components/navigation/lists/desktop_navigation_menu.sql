prompt --application/shared_components/navigation/lists/desktop_navigation_menu
begin
--   Manifest
--     LIST: Desktop Navigation Menu
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>22940
,p_default_id_offset=>32959023425505623190
,p_default_owner=>'JK64'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(58145284965645128589)
,p_name=>'Desktop Navigation Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33067568022031664007)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Demo Home'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32992304829375080019)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Visualisations'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-eye'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(58145328915061128742)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Report Pins'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-map-marker'
,p_parent_list_item_id=>wwv_flow_api.id(32992304829375080019)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33021817949558742237)
,p_list_item_display_sequence=>320
,p_list_item_link_text=>'PL/SQL Function returning SQL Query'
,p_list_item_link_target=>'f?p=&APP_ID.:29:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-code'
,p_parent_list_item_id=>wwv_flow_api.id(58145328915061128742)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33021818776286749941)
,p_list_item_display_sequence=>330
,p_list_item_link_text=>'Table or View'
,p_list_item_link_target=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-database'
,p_parent_list_item_id=>wwv_flow_api.id(58145328915061128742)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'30'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33069592919912367512)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>'Route Map'
,p_list_item_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-car'
,p_parent_list_item_id=>wwv_flow_api.id(32992304829375080019)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32991282833358242357)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>'Marker Clustering'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-plus-circle'
,p_parent_list_item_id=>wwv_flow_api.id(32992304829375080019)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33012932589702615191)
,p_list_item_display_sequence=>180
,p_list_item_link_text=>'Spiderfier'
,p_list_item_link_target=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-asterisk'
,p_parent_list_item_id=>wwv_flow_api.id(32992304829375080019)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'24'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32991301264968558907)
,p_list_item_display_sequence=>190
,p_list_item_link_text=>'Geo Heatmap'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-globe'
,p_parent_list_item_id=>wwv_flow_api.id(32992304829375080019)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33013706970939282040)
,p_list_item_display_sequence=>200
,p_list_item_link_text=>'GeoJSON'
,p_list_item_link_target=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-radar-chart'
,p_parent_list_item_id=>wwv_flow_api.id(32992304829375080019)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'27'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32992297439010049632)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Marker Styling'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-map-marker'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33068914363443059734)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Pin Labels'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-tag'
,p_parent_list_item_id=>wwv_flow_api.id(32992297439010049632)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32992268335808595219)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>'Pin Icons'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-plane'
,p_parent_list_item_id=>wwv_flow_api.id(32992297439010049632)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32992288519311943302)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Static Icons'
,p_list_item_link_target=>'f?p=&APP_ID.:16:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-image-o'
,p_parent_list_item_id=>wwv_flow_api.id(32992297439010049632)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33013169228192906498)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Custom'
,p_list_item_link_target=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-design'
,p_parent_list_item_id=>wwv_flow_api.id(32992297439010049632)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'25'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32992304004430072637)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Geocoding'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-compass'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33034569135198746830)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Search Map'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-search'
,p_parent_list_item_id=>wwv_flow_api.id(32992304004430072637)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33096079445218769053)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Geolocate'
,p_list_item_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bolt'
,p_parent_list_item_id=>wwv_flow_api.id(32992304004430072637)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33041124154386171545)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Directions'
,p_list_item_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-map-signs'
,p_parent_list_item_id=>wwv_flow_api.id(32992304004430072637)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32992305936421091488)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Custom Behaviour'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-gears'
,p_list_item_current_type=>'NEVER'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33034111914943582754)
,p_list_item_display_sequence=>210
,p_list_item_link_text=>'Sync with Report'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-refresh'
,p_parent_list_item_id=>wwv_flow_api.id(32992305936421091488)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32991262918617091894)
,p_list_item_display_sequence=>220
,p_list_item_link_text=>'Draggable Pins'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-arrows-alt'
,p_parent_list_item_id=>wwv_flow_api.id(32992305936421091488)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32991942220199956478)
,p_list_item_display_sequence=>230
,p_list_item_link_text=>'Disabled Pan / Zoom'
,p_list_item_link_target=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-ban'
,p_parent_list_item_id=>wwv_flow_api.id(32992305936421091488)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32991724023815403054)
,p_list_item_display_sequence=>240
,p_list_item_link_text=>'Javascript Initialization'
,p_list_item_link_target=>'f?p=&APP_ID.:13:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-code'
,p_parent_list_item_id=>wwv_flow_api.id(32992305936421091488)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32992409111680832733)
,p_list_item_display_sequence=>250
,p_list_item_link_text=>'Flex Fields'
,p_list_item_link_target=>'f?p=&APP_ID.:17:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-database'
,p_parent_list_item_id=>wwv_flow_api.id(32992305936421091488)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32993025132928578297)
,p_list_item_display_sequence=>260
,p_list_item_link_text=>'Map Layers'
,p_list_item_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-layers'
,p_parent_list_item_id=>wwv_flow_api.id(32992305936421091488)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33007420744966220227)
,p_list_item_display_sequence=>270
,p_list_item_link_text=>'Event: Marker Added'
,p_list_item_link_target=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-trigger'
,p_parent_list_item_id=>wwv_flow_api.id(32992305936421091488)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'20'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33013242192413107654)
,p_list_item_display_sequence=>280
,p_list_item_link_text=>'Batched Results'
,p_list_item_link_target=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-hourglass-2'
,p_parent_list_item_id=>wwv_flow_api.id(32992305936421091488)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33012834557072903478)
,p_list_item_display_sequence=>290
,p_list_item_link_text=>'Localisation'
,p_list_item_link_target=>'f?p=&APP_ID.:21:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-language'
,p_parent_list_item_id=>wwv_flow_api.id(32992305936421091488)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'21'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33017524774244887134)
,p_list_item_display_sequence=>310
,p_list_item_link_text=>'Controlling the Map'
,p_list_item_link_target=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-times-square-o'
,p_parent_list_item_id=>wwv_flow_api.id(32992305936421091488)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'28'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33003692606183314346)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Drawing & GeoJSON'
,p_list_item_link_target=>'f?p=&APP_ID.:19:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-pencil-square-o'
,p_list_text_01=>'Draw shapes (polygons) onto the map. Drag-and-drop GeoJSON files onto the map. Export features as a GeoJSON document.'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'19'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33009314025945506738)
,p_list_item_display_sequence=>300
,p_list_item_link_text=>'Load GeoJSON via JavaScript'
,p_list_item_link_target=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.:22:::'
,p_parent_list_item_id=>wwv_flow_api.id(33003692606183314346)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'22'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(32991953574474018845)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'A Tale of Two Cities'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-clone'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33027000022912050601)
,p_list_item_display_sequence=>340
,p_list_item_link_text=>'Failure Modes'
,p_list_item_icon=>'fa-exclamation-triangle'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(33027000311244048467)
,p_list_item_display_sequence=>350
,p_list_item_link_text=>'Data error handling'
,p_list_item_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_api.id(33027000022912050601)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
