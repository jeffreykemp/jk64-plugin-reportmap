prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>22940
,p_default_id_offset=>32959023425505623190
,p_default_owner=>'JK64'
);
wwv_flow_api.create_page(
 p_id=>5
,p_user_interface_id=>wwv_flow_api.id(58145327374438128653)
,p_name=>'Search Map'
,p_alias=>'SEARCH'
,p_step_title=>'Search Map'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'Enter a <b>Search</b> string - e.g. an address, place name or landmark. The item',
'has an onchange dynamic action that executes a <strong>JK64 Report Google Map R1 Action</strong>',
'set to <strong>Search map by Address</strong>.',
'</p><p>',
'When it is found, the map raises the <strong>addressFound</strong> event.',
'</p><p>',
'A dynamic action on the region then executes the following Actions:',
'<ol><li>Execute JavaScript Code:',
'<code>',
'    this.data.map.setCenter({lat:this.data.lat,lng:this.data.lng});',
'    this.data.map.setZoom(17);',
'</code>',
'</li><li>Set Value, on item P5_ADDRESS, to JavaScript Expression:',
'<code>',
'    this.data.result.formatted_address',
'</code>',
'</li><li>Set Value, on item P5_DSP_LAT_LNG, to JavaScript Expression:',
'<code>',
'    this.data.lat + " " + this.data.lng);',
'</code>',
'</li></ol>',
'</p><p>',
'Alternatively, if you click any point on the map, the <strong>mapClick</strong>',
'event fires and a dynamic action executes a <strong>JK64 Report Google Map R1 Action</strong>',
'set to <strong>Place Marker</strong> based on a JavaScript Expression:',
'<code>',
'    {"lat":this.data.lat, "lng":this.data.lng}',
'</code>',
'Followed by another <strong>JK64 Report Google Map R1 Action</strong> set to',
'<strong>Get Address at Location</strong> based on the same JavaScript expression.',
'</p><p>',
'The maps "Draggable" option is set. This means the marker can be dragged to a new location; when this occurs, the <strong>markerDrag</strong> event fires and a',
'dynamic action calls <code>Get Address at Location</code> again.',
'</p><p>',
'If the <b>Region</b> is selected, the search will <em>bias</em> the results to the selected region if multiple results are found.',
'</p><p>',
'If the <b>Country</b> is selected, the results will be <em>restricted</em> to the selected country.',
'</p><p>',
'When the Country is changed, a dynamic action performs three actions:',
'<ol>',
'<li>Set Value - retrieves the lat,lng for the country into P5_LATLNG</li>',
'<li>Javascript:',
'    <code>',
'        $("#map_mymap").reportmap("option","restrictCountry",$v("P5_COUNTRY"));',
'    </code>',
'</li>',
'    <li><strong>JK64 Report Google Map R1 Action</strong> set to <strong>Pan To</strong> based on P5_LATLNG.</li>',
'</ol>',
'</p>'))
,p_page_comment=>'This page requires the table jk64demo_countries.'
,p_last_updated_by=>'JEFF'
,p_last_upd_yyyymmddhh24miss=>'20200527155241'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(32981190661558991625)
,p_plug_name=>'Notes'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(58145301145361128614)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_HELP_TEXT'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(32991961672540031904)
,p_plug_name=>'Search Map'
,p_region_name=>'mymap'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(58145293116210128605)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'600'
,p_attribute_02=>'PINS'
,p_attribute_03=>'13'
,p_attribute_04=>'PAN_ON_CLICK:DRAGGABLE:PAN_ALLOWED:ZOOM_ALLOWED:SPINNER'
,p_attribute_06=>'&P5_LATLNG.'
,p_attribute_09=>'&P5_REGION.'
,p_attribute_10=>'&P5_COUNTRY.'
,p_attribute_12=>'N'
,p_attribute_21=>'N'
,p_attribute_22=>'ROADMAP'
,p_attribute_24=>'Y'
,p_attribute_25=>'auto'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33012998404190179494)
,p_name=>'P5_REGION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(32981190661558991625)
,p_prompt=>'Bias to Region'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select country, iso_a2 from jk64demo_countries where iso_a2 is not null order by 1'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'default bias (US)'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(32992891694697320257)
,p_item_icon_css_classes=>'fa-globe'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'REDIRECT_SET_VALUE'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33029279676804715821)
,p_name=>'P5_SEARCH'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(32981190661558991625)
,p_prompt=>'Search'
,p_placeholder=>'enter address to search for'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_field_template=>wwv_flow_api.id(32992891694697320257)
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33029279732283715822)
,p_name=>'P5_ADDRESS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(32981190661558991625)
,p_prompt=>'Address'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'readonly'
,p_field_template=>wwv_flow_api.id(32992891694697320257)
,p_item_icon_css_classes=>'fa-envelope-square'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33029279889669715823)
,p_name=>'P5_COUNTRY'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(32981190661558991625)
,p_prompt=>'Restrict to Country'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select country, iso_a2 from jk64demo_countries where iso_a2 is not null and lat is not null and lng is not null order by 1'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'(all countries)'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(32992891694697320257)
,p_item_icon_css_classes=>'fa-map-marker'
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33029279955859715824)
,p_name=>'P5_LATLNG'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(32981190661558991625)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33061180343552976199)
,p_name=>'P5_DSP_LAT_LNG'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(32981190661558991625)
,p_prompt=>'Lat/Long'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'readonly'
,p_field_template=>wwv_flow_api.id(32992891694697320257)
,p_item_icon_css_classes=>'fa-map-pin'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_computation(
 p_id=>wwv_flow_api.id(33029280285362715827)
,p_computation_sequence=>10
,p_computation_item=>'P5_LATLNG'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT lat||'',''||lng',
'FROM jk64demo_countries',
'WHERE iso_a2 = :P5_COUNTRY'))
,p_compute_when=>'P5_COUNTRY'
,p_compute_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(33061180153944976197)
,p_name=>'addressFound'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(32991961672540031904)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|addressfound'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33061180323696976198)
,p_event_id=>wwv_flow_api.id(33061180153944976197)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_DA_R1'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(32991961672540031904)
,p_attribute_01=>'panTo'
,p_attribute_02=>'javascriptExpression'
,p_attribute_06=>'this.data.lat + " " + this.data.lng'
,p_attribute_07=>'zoom'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33016908133873465291)
,p_event_id=>wwv_flow_api.id(33061180153944976197)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_DA_R1'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(32991961672540031904)
,p_attribute_01=>'setOption'
,p_attribute_02=>'static'
,p_attribute_05=>'17'
,p_attribute_07=>'zoom'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(32992414954387841605)
,p_event_id=>wwv_flow_api.id(33061180153944976197)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P5_ADDRESS'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.data.result.formatted_address'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(32992415077916841606)
,p_event_id=>wwv_flow_api.id(33061180153944976197)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P5_LATLNG,P5_DSP_LAT_LNG'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.data.lat + " " + this.data.lng'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(32981189562597991614)
,p_name=>'on search'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P5_SEARCH'
,p_condition_element=>'P5_SEARCH'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33013002185483179532)
,p_event_id=>wwv_flow_api.id(32981189562597991614)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_DA_R1'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(32991961672540031904)
,p_attribute_01=>'gotoAddress'
,p_attribute_02=>'triggeringElement'
,p_attribute_07=>'zoom'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(32981191135692991630)
,p_name=>'mapclick - get address'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(32991961672540031904)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|mapclick'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33013002939722179540)
,p_event_id=>wwv_flow_api.id(32981191135692991630)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_DA_R1'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(32991961672540031904)
,p_attribute_01=>'gotoPosByString'
,p_attribute_02=>'javascriptExpression'
,p_attribute_06=>'{"lat":this.data.lat,"lng":this.data.lng}'
,p_attribute_07=>'zoom'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(32981191307811991631)
,p_event_id=>wwv_flow_api.id(32981191135692991630)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_DA_R1'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(32991961672540031904)
,p_attribute_01=>'getAddressByPos'
,p_attribute_02=>'javascriptExpression'
,p_attribute_06=>'{"lat":this.data.lat,"lng":this.data.lng}'
,p_attribute_07=>'zoom'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(33013000507703179515)
,p_name=>'markerDrag'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(32991961672540031904)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|markerdrag'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33013000590280179516)
,p_event_id=>wwv_flow_api.id(33013000507703179515)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_DA_R1'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(32991961672540031904)
,p_attribute_01=>'getAddressByPos'
,p_attribute_02=>'javascriptExpression'
,p_attribute_06=>'{"lat":this.data.lat,"lng":this.data.lng}'
,p_attribute_07=>'zoom'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(32991961808821031905)
,p_name=>'on change country'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P5_COUNTRY'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(32991961827155031906)
,p_event_id=>wwv_flow_api.id(32991961808821031905)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P5_LATLNG'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT lat||'',''||lng',
'FROM jk64demo_countries',
'WHERE iso_a2 = :P5_COUNTRY'))
,p_attribute_07=>'P5_COUNTRY'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(32991961964130031907)
,p_event_id=>wwv_flow_api.id(32991961808821031905)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_DA_R1'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(32991961672540031904)
,p_attribute_01=>'setOption'
,p_attribute_02=>'triggeringElement'
,p_attribute_07=>'restrictCountry'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33016909267587465302)
,p_event_id=>wwv_flow_api.id(32991961808821031905)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_DA_R1'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(32991961672540031904)
,p_attribute_01=>'panTo'
,p_attribute_02=>'pageItem'
,p_attribute_03=>'P5_LATLNG'
,p_attribute_07=>'zoom'
);
wwv_flow_api.component_end;
end;
/
