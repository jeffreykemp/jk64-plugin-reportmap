prompt --application/pages/page_00016
begin
--   Manifest
--     PAGE: 00016
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>22940
,p_default_id_offset=>32959023425505623190
,p_default_owner=>'JK64'
);
wwv_flow_api.create_page(
 p_id=>16
,p_user_interface_id=>wwv_flow_api.id(58145327374438128653)
,p_name=>'Application Static Icons'
,p_alias=>'STATIC'
,p_step_title=>'Application Static Icons'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'The column <strong>Icon</strong> in the report can refer to icons loaded from application static files.',
'<p>',
'Query for map plugin:',
'<code>',
'    select c003 as lat, c004 as lng, c002 as name,',
'           c001 as id, c002 || '' (id='' || c001 || '')'' as info ,',
'           c008 AS icon',
'    from apex_collections',
'    where collection_name = ''MAP''',
'</code>',
'<p>',
'The <b>JavaScript Initialization Code</b> is set to:',
'<code>',
'    this.options.iconBasePath = ''&#35;APP_IMAGES#'';',
'</code>'))
,p_last_updated_by=>'JEFF'
,p_last_upd_yyyymmddhh24miss=>'20200520083038'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33058471297808324015)
,p_plug_name=>'Report Google Map Plugin with Static Icons'
,p_region_name=>'mymap'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(58145293116210128605)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c003 as lat, c004 as lng, c002 as name, c001 as id, c002 || '' (id='' || c001 || '')'' as info',
'      ,c008 as icon',
'from apex_collections',
'where collection_name = ''MAP''',
'and (c003!=0 or c004!=0)'))
,p_plug_source_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plugin_init_javascript_code=>'this.options.iconBasePath = ''#APP_IMAGES#'';'
,p_attribute_01=>'350'
,p_attribute_02=>'PINS'
,p_attribute_03=>'13'
,p_attribute_04=>'PAN_ON_CLICK:PAN_ALLOWED:ZOOM_ALLOWED:SPINNER'
,p_attribute_12=>'N'
,p_attribute_21=>'N'
,p_attribute_22=>'ROADMAP'
,p_attribute_24=>'Y'
,p_attribute_25=>'auto'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(33135424766771351853)
,p_name=>'Source data'
,p_template=>wwv_flow_api.id(58145301145361128614)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c003 as lat, c004 as lng, c002 as name, c001 as id, c002 || '' (id='' || c001 || '')'' as info',
'      ,c008 as icon',
'from apex_collections',
'where collection_name = ''MAP''',
'and (c003!=0 or c004!=0)'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(58145310002113128622)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32992289783905943330)
,p_query_column_id=>1
,p_column_alias=>'LAT'
,p_column_display_sequence=>1
,p_column_heading=>'Lat'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32992290167931943333)
,p_query_column_id=>2
,p_column_alias=>'LNG'
,p_column_display_sequence=>2
,p_column_heading=>'Lng'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32992290588096943333)
,p_query_column_id=>3
,p_column_alias=>'NAME'
,p_column_display_sequence=>3
,p_column_heading=>'Name'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32992291005627943333)
,p_query_column_id=>4
,p_column_alias=>'ID'
,p_column_display_sequence=>4
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32992291348803943333)
,p_query_column_id=>5
,p_column_alias=>'INFO'
,p_column_display_sequence=>5
,p_column_heading=>'Info'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(32992291745813943334)
,p_query_column_id=>6
,p_column_alias=>'ICON'
,p_column_display_sequence=>6
,p_column_heading=>'Icon'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33135431181089351865)
,p_plug_name=>'Notes'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(58145301145361128614)
,p_plug_display_sequence=>20
,p_plug_grid_column_span=>5
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_HELP_TEXT'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.component_end;
end;
/
