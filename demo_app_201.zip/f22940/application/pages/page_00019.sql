prompt --application/pages/page_00019
begin
--   Manifest
--     PAGE: 00019
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>22940
,p_default_id_offset=>32959023425505623190
,p_default_owner=>'JK64'
);
wwv_flow_api.create_page(
 p_id=>19
,p_user_interface_id=>wwv_flow_api.id(58145327374438128653)
,p_name=>'Drawing & GeoJSON'
,p_alias=>'DRAWING'
,p_step_title=>'Drawing & GeoJSON'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'JEFF'
,p_last_upd_yyyymmddhh24miss=>'20200527155241'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33001667528802229909)
,p_plug_name=>'Info'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(58145301145361128614)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ul><li>',
'',
'The "Drag & Drop GeoJSON" is an option that can be enabled on the plugin. This causes the plugin to render a drag-and-drop div over the map that responds to the user dropping a JSON fragment or a file containing JSON.',
'',
'</li><li>',
'',
'The "Drawing Mode" feature is enabled by choosing one or more shape types (marker, polygon, polyline, rectangle, and/or circle). If this is enabled, the plugin renders the drawing buttons at the top of the map, including controls for deleting feature'
||'s.',
'',
'</li><li>',
'',
'To export all the features on the map as a GeoJSON file, use javascript like this:',
'<code>',
'var map = $("#map_testmap").reportmap("instance").map;',
'map.data.toGeoJson(function(o){',
'    $s("P19_GEOJSON", JSON.stringify(o));',
'});',
'</code>',
'',
'</li><li>',
'',
'These features, including those loaded from a GeoJSON file, are drawn using the Google Maps "Data Layer"; they are separate from any report pins rendered from the SQL query; the report pins are not drawn in the data layer so would not be exported as '
||'GeoJSON.',
'',
'</li><li>',
'',
'To load GeoJSON onto the map, use the <strong>JK64 Report Google Map R1 Action</strong> dynamic action with Action set to <strong>Load GeoJSON</strong>.',
'',
'<p>',
'',
'Alternatively, the following Javascript API call can be used:',
'<code>',
'$("#map_testmap").reportmap("loadGeoJsonString", ''...your geoJON here...'');',
'</code>',
'',
'</li></ul>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33089981208942241124)
,p_plug_name=>'Drawing & GeoJSON'
,p_region_name=>'testmap'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(58145301145361128614)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'400'
,p_attribute_02=>'PINS'
,p_attribute_04=>'PAN_ON_CLICK:DRAGGABLE:PAN_ALLOWED:ZOOM_ALLOWED:GEOJSON_DRAGDROP:SPINNER'
,p_attribute_12=>'N'
,p_attribute_16=>'polygon:rectangle'
,p_attribute_21=>'N'
,p_attribute_22=>'ROADMAP'
,p_attribute_24=>'Y'
,p_attribute_25=>'greedy'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33089985699710323614)
,p_plug_name=>'Features'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(58145297448223128610)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ul><li>',
'Drag-and-drop a geoJSON document or file onto the map.',
'</li><li>',
'Add one or more features to the map using the polygon or rectangle tool.',
'</li><li>',
'Select a feature to edit or move it. It will be shown in red when it is editable. You can move the vertices or add more vertices.',
'</li><li>',
'To add a hole to a polygon:',
'  <ol><li>',
'  Select the polygon to which you wish to add a hole (it will be shown in red)',
'  </li><li>',
'  Click the "hole" checkbox',
'  </li><li>',
'  Draw another polygon (or rectangle) within the polygon.',
'  </li></ol>',
'</li><li>',
'Delete selected or all polygons (e.g. select the objects, then either click the trashcan icon or press the Delete key).',
'</li><li>',
'Export the data as a geoJSON document.',
'</li></ul>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(33003693227178314335)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(33089981208942241124)
,p_button_name=>'GET_GEOJSON'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(58145322285602128635)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Get GeoJSON'
,p_button_position=>'BODY'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-download'
,p_grid_new_row=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(33001667193945229905)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(33089985699710323614)
,p_button_name=>'LOAD_SAMPLE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--success:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(58145322285602128635)
,p_button_image_alt=>'Load Sample'
,p_button_position=>'REGION_TEMPLATE_EDIT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-upload'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33001667467949229908)
,p_name=>'P19_JSON_INDENT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(33089981208942241124)
,p_prompt=>'JSON indent'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:1 space;1,2 spaces;2,4 spaces;4'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'none'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(58145321701108128634)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_help_text=>'This controls how the GeoJSON is converted to a string.'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33003693695896314331)
,p_name=>'P19_GEOJSON'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(33089981208942241124)
,p_prompt=>'GeoJSON'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>16
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_api.id(58145321546870128633)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(33003695814661314308)
,p_name=>'get geojson'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(33003693227178314335)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33003696313425314307)
,p_event_id=>wwv_flow_api.id(33003695814661314308)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var map = $("#map_testmap").reportmap("instance").map;',
'map.data.toGeoJson(function(o){',
'    $s("P19_GEOJSON", JSON.stringify(o,null,''    ''.substring(0,$v("P19_JSON_INDENT"))));',
'});'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(33003698471940314306)
,p_name=>'loadedGeoJson'
,p_event_sequence=>70
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(33089981208942241124)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|loadedgeojson'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33003698990334314306)
,p_event_id=>wwv_flow_api.id(33003698471940314306)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s("P19_GEOJSON", JSON.stringify(this.data.geoJson,null,''    ''.substring(0,$v("P19_JSON_INDENT"))));'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(33003696716312314307)
,p_name=>'addFeature'
,p_event_sequence=>80
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(33089981208942241124)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|addfeature'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33003697162676314307)
,p_event_id=>wwv_flow_api.id(33003696716312314307)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'this.data.map.data.toGeoJson(function(o){',
'    $s("P19_GEOJSON", JSON.stringify(o,null,''    ''.substring(0,$v("P19_JSON_INDENT"))));',
'});'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(33003699236803314306)
,p_name=>'setGeometry'
,p_event_sequence=>90
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(33089981208942241124)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|setgeometry'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33003699750151314305)
,p_event_id=>wwv_flow_api.id(33003699236803314306)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'this.data.map.data.toGeoJson(function(o){',
'    $s("P19_GEOJSON", JSON.stringify(o,null,''    ''.substring(0,$v("P19_JSON_INDENT"))));',
'});'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(33003697625389314306)
,p_name=>'removeFeature'
,p_event_sequence=>100
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(33089981208942241124)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|removefeature'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33003698117448314306)
,p_event_id=>wwv_flow_api.id(33003697625389314306)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'this.data.map.data.toGeoJson(function(o){',
'    $s("P19_GEOJSON", JSON.stringify(o,null,''    ''.substring(0,$v("P19_JSON_INDENT"))));',
'});'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(33001667281480229906)
,p_name=>'click load sample'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(33001667193945229905)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33001667422569229907)
,p_event_id=>wwv_flow_api.id(33001667281480229906)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_DA_R1'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(33089981208942241124)
,p_attribute_01=>'loadGeoJsonString'
,p_attribute_02=>'static'
,p_attribute_05=>'{"type":"FeatureCollection","features":[{"type":"Feature","geometry":{"type":"Polygon","coordinates":[[[115.81810956058052,-31.97383444279713],[115.81816320476082,-31.965348125709053],[115.81942705955316,-31.963045289361652],[115.83356551761699,-31.9'
||'50765554651483],[115.84524707746186,-31.954567079185118],[115.84569017891499,-31.959739299429998],[115.8460045343354,-31.961616227489593],[115.8422644610373,-31.963072596059856],[115.84141044463922,-31.964019223244122],[115.84023992757739,-31.9647983'
||'62690065],[115.83827547664714,-31.967871166607786],[115.83664147701074,-31.96930650292521],[115.83428864535836,-31.970050102393433],[115.83351831178607,-31.971133179223234],[115.83172337698943,-31.97200873460981],[115.8272462331779,-31.97259304090624'
||'],[115.82645659503487,-31.97074727635052],[115.82297186593951,-31.97255845111874],[115.81810956058052,-31.97383444279713]],[[115.82864956807771,-31.962373541584306],[115.83208279561677,-31.964485251059358],[115.83534436177888,-31.962373541584306],[11'
||'5.83534436177888,-31.957567401061706],[115.83208279561677,-31.959351528034734],[115.82847790670075,-31.957640223249268],[115.82864956807771,-31.962373541584306]]]}}]}'
,p_attribute_07=>'zoom'
);
wwv_flow_api.component_end;
end;
/
