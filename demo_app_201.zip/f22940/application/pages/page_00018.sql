prompt --application/pages/page_00018
begin
--   Manifest
--     PAGE: 00018
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>22940
,p_default_id_offset=>32959023425505623190
,p_default_owner=>'JK64'
);
wwv_flow_api.create_page(
 p_id=>18
,p_user_interface_id=>wwv_flow_api.id(58145327374438128653)
,p_name=>'Map Layers'
,p_alias=>'LAYERS'
,p_step_title=>'Map Layers'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'This page demonstrates how to add a Layer to the map. Google Maps provides three layers: Traffic, Transit, and Bicycling.',
'<p>',
'On change of the select list item, the following JavaScript is run:',
'<code>',
'    // remove the previous layer, if it exists',
'    if (typeof lyr===''object'') { lyr.setMap(null); }',
'    delete lyr;',
'    // get the layer',
'    switch ($v("P18_LAYER")) {',
'      case ''traffic'': lyr = new google.maps.TrafficLayer(); break;',
'      case ''transit'': lyr = new google.maps.TransitLayer(); break;',
'      case ''bicycling'': lyr = new google.maps.BicyclingLayer(); break;',
'    }',
'    // put the layer on the map',
'    lyr.setMap( $("#map_mymap").reportmap("instance").map );',
'</code>'))
,p_last_updated_by=>'JEFF'
,p_last_upd_yyyymmddhh24miss=>'20200520083038'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(32992415419533841609)
,p_plug_name=>'Map Layers'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(58145301145361128614)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_HELP_TEXT'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(32993025575776578303)
,p_plug_name=>'Map'
,p_region_name=>'mymap'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(58145301145361128614)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'350'
,p_attribute_02=>'PINS'
,p_attribute_04=>'PAN_ON_CLICK:PAN_ALLOWED:ZOOM_ALLOWED:SPINNER'
,p_attribute_05=>'11'
,p_attribute_06=>'40.710,-73.984'
,p_attribute_12=>'N'
,p_attribute_21=>'N'
,p_attribute_22=>'ROADMAP'
,p_attribute_24=>'Y'
,p_attribute_25=>'auto'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32992415452363841610)
,p_name=>'P18_LAYER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(32992415419533841609)
,p_prompt=>'Layer'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Traffic;traffic,Transit;transit,Bicycling;bicycling'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'(select a layer)'
,p_cHeight=>1
,p_colspan=>4
,p_grid_column=>3
,p_field_template=>wwv_flow_api.id(32992891694697320257)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(32992415728041841613)
,p_name=>'on change'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P18_LAYER'
,p_condition_element=>'P18_LAYER'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(32992415830369841614)
,p_event_id=>wwv_flow_api.id(32992415728041841613)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (typeof lyr===''object'') { lyr.setMap(null); }',
'delete lyr;',
'switch ($v("P18_LAYER")) {',
'  case ''traffic'': lyr = new google.maps.TrafficLayer(); break;',
'  case ''transit'': lyr = new google.maps.TransitLayer(); break;',
'  case ''bicycling'': lyr = new google.maps.BicyclingLayer(); break;',
'}',
'lyr.setMap( $("#map_mymap").reportmap("instance").map );'))
);
wwv_flow_api.component_end;
end;
/
