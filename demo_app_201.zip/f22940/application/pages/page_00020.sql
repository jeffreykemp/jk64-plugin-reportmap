prompt --application/pages/page_00020
begin
--   Manifest
--     PAGE: 00020
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>22940
,p_default_id_offset=>32959023425505623190
,p_default_owner=>'JK64'
);
wwv_flow_api.create_page(
 p_id=>20
,p_user_interface_id=>wwv_flow_api.id(58145327374438128653)
,p_name=>'Event: Marker Added'
,p_alias=>'MARKERADDED'
,p_step_title=>'Event: Marker Added'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<strong>When a pin is first shown, the marker added event is fired.</strong>',
'<p>',
'<p>',
'Dynamic action on plugin event <strong>markerAdded</strong> that executes the following JavaScript:',
'<code>',
'    $s("P20_IDLIST", $v("P20_IDLIST")+" "+this.data.id);',
'    this.data.marker.setAnimation(google.maps.Animation.DROP);',
'</code>',
'<p>',
'(When the map is refreshed, the "log" is cleared)',
'<p>',
'Notice that when switching from Data Set #1 to Data Set #2 (or vice versa), only those data points',
'that were not previously shown are triggered.'))
,p_last_updated_by=>'JEFF'
,p_last_upd_yyyymmddhh24miss=>'20200520083038'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33080928028143458660)
,p_plug_name=>'Event: Marker Added'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(58145301145361128614)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_HELP_TEXT'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(36221894446718027840)
,p_plug_name=>'Report Map'
,p_region_name=>'mymap'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(58145301145361128614)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c003 as lat, c004 as lng, c002 as name, c001 as id, c002 || '' (id='' || c001 || '')'' as info',
'from apex_collections',
'where collection_name = ''MAP''',
'and c001 != ''14'' /*exclude Null Island*/',
'and case',
'    when :P20_SUBSET=''1'' and substr(upper(c002),1,1) between ''A'' and ''R'' then ''Y''',
'    when :P20_SUBSET=''2'' and substr(upper(c002),1,1) between ''H'' and ''Z'' then ''Y''',
'    when :P20_SUBSET=''S'' and c001 = ''6'' then ''Y''',
'    end = ''Y'''))
,p_plug_source_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1'
,p_ajax_items_to_submit=>'P20_SUBSET'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'350'
,p_attribute_02=>'PINS'
,p_attribute_04=>'PAN_ON_CLICK:PAN_ALLOWED:ZOOM_ALLOWED:SPINNER'
,p_attribute_12=>'N'
,p_attribute_21=>'N'
,p_attribute_22=>'ROADMAP'
,p_attribute_24=>'Y'
,p_attribute_25=>'auto'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(36221894643193027842)
,p_name=>'Source data'
,p_template=>wwv_flow_api.id(58145301145361128614)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c003 as lat, c004 as lng, c002 as name, c001 as id, c002 || '' (id='' || c001 || '')'' as info ',
'from apex_collections',
'where collection_name = ''MAP''',
'and c001 != ''14'' /*exclude Null Island*/'))
,p_ajax_enabled=>'Y'
,p_query_row_template=>wwv_flow_api.id(58145310002113128622)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(33007422737004220267)
,p_query_column_id=>1
,p_column_alias=>'LAT'
,p_column_display_sequence=>1
,p_column_heading=>'Lat'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(33007423213182220270)
,p_query_column_id=>2
,p_column_alias=>'LNG'
,p_column_display_sequence=>2
,p_column_heading=>'Lng'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(33007423557139220270)
,p_query_column_id=>3
,p_column_alias=>'NAME'
,p_column_display_sequence=>3
,p_column_heading=>'Name'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(33007423983522220270)
,p_query_column_id=>4
,p_column_alias=>'ID'
,p_column_display_sequence=>4
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(33007424387316220270)
,p_query_column_id=>5
,p_column_alias=>'INFO'
,p_column_display_sequence=>5
,p_column_heading=>'Info'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32976520381276002434)
,p_name=>'P20_SUBSET'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(33080928028143458660)
,p_prompt=>'Data Subset'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Data Set #1;1,Data Set #2;2,Single Pin;S'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'(none)'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(32992891694697320257)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32976520833344002439)
,p_name=>'P20_IDLIST'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(33080928028143458660)
,p_prompt=>'ID List'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(32992891694697320257)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(32976520474951002435)
,p_name=>'on change subset'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P20_SUBSET'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(32976520949936002440)
,p_event_id=>wwv_flow_api.id(32976520474951002435)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P20_IDLIST'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(32976520551274002436)
,p_event_id=>wwv_flow_api.id(32976520474951002435)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(36221894446718027840)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(32976520687356002437)
,p_name=>'markerAdded'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(36221894446718027840)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|markeradded'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(32976520777750002438)
,p_event_id=>wwv_flow_api.id(32976520687356002437)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$s("P20_IDLIST", $v("P20_IDLIST")+" "+this.data.id);',
'this.data.marker.setAnimation(google.maps.Animation.DROP);'))
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33007438634330705505)
,p_event_id=>wwv_flow_api.id(32976520687356002437)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (this.data.id == "6") {',
'    this.data.marker.info = "Rottnest Island";',
'    $("#map_mymap").reportmap("showInfoWindow", this.data.marker);',
'}'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(33007438239363705501)
,p_name=>'markerClick'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(36221894446718027840)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|markerclick'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33007438364563705502)
,p_event_id=>wwv_flow_api.id(33007438239363705501)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.debug(this.data);'
);
wwv_flow_api.component_end;
end;
/
