prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>22940
,p_default_id_offset=>32959023425505623190
,p_default_owner=>'JK64'
);
wwv_flow_api.create_page(
 p_id=>7
,p_user_interface_id=>wwv_flow_api.id(58145327374438128653)
,p_name=>'Directions'
,p_alias=>'DIRECTIONS'
,p_step_title=>'Directions'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<hr>',
'Directions between two locations can be shown. Locations may be entered as lat,lng pairs or as addresses or place names.',
'<p>',
'The resulting route is shown on the map, and (optionally) the directions in human-readable form are listed in another region. The total distance (in metres) and duration (in seconds) can be set on a page item you specify. This is done by a dynamic ac'
||'tion on the Travel Mode, Origin and Destination items that executes the following javascript:',
'<code>',
'    $("#map_mymap").reportmap("showDirections",',
'        $v("P7_ORIGIN"),',
'        $v("P7_DEST"),',
'        $v("P7_TRAVEL_MODE"));',
'</code>',
'<p>',
'The map then triggers the "directions" event which is used to set the total distance (in metres) and duration (in seconds).',
'<code>',
'    $s("P7_DISTANCE",this.data.distance);',
'    $s("P7_DURATION",this.data.duration);',
'</code>',
'Subsequent dynamic actions convert these results to kilometres and minutes.',
'<p>',
'The Directions Panel is an ordinary APEX region with the following contents:',
'<code>',
'    &lt;div id="directionspanel">&lt;/div>',
'</code>',
'The <strong>JavaScript Initialization Code</strong> on the plugin is:',
'<code>',
'    this.options.directionsPanel = "directionspanel";',
'</code>',
'<p>',
'Have a peek in your browser console log; you will find the complete output of the DirectionsResponse, a javascript object which includes all details of the route and turn-by-turn instructions.',
'</p>',
'<p>',
'If you click the map, a dynamic action is triggered ("mapClick") which executes the following:',
'<code>',
'    if ($v("P7_ORIGIN")=="") {',
'      $s("P7_ORIGIN", this.data.lat+","+this.data.lng);',
'    } else {',
'      $s("P7_DEST", this.data.lat+","+this.data.lng);',
'    }',
'</code>'))
,p_last_updated_by=>'JEFF'
,p_last_upd_yyyymmddhh24miss=>'20200520083038'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33012456913340181422)
,p_plug_name=>'column1'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(58145301145361128614)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(32991962266473031910)
,p_plug_name=>'Directions ("mymap")'
,p_region_name=>'mymap'
,p_parent_plug_id=>wwv_flow_api.id(33012456913340181422)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(58145293116210128605)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plugin_init_javascript_code=>'this.options.directionsPanel = "directionspanel";'
,p_attribute_01=>'550'
,p_attribute_02=>'PINS'
,p_attribute_03=>'13'
,p_attribute_04=>'PAN_ON_CLICK:PAN_ALLOWED:ZOOM_ALLOWED:SPINNER'
,p_attribute_12=>'N'
,p_attribute_21=>'N'
,p_attribute_22=>'ROADMAP'
,p_attribute_24=>'Y'
,p_attribute_25=>'auto'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33012457105608181424)
,p_plug_name=>'Parameters'
,p_parent_plug_id=>wwv_flow_api.id(33012456913340181422)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(58145301145361128614)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33012456979076181423)
,p_plug_name=>'column1'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(58145301145361128614)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33012456259085181416)
,p_plug_name=>'Directions panel'
,p_parent_plug_id=>wwv_flow_api.id(33012456979076181423)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(58145301145361128614)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_source=>'<div id="directionspanel"></div>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33034687420473673835)
,p_plug_name=>'About this page'
,p_parent_plug_id=>wwv_flow_api.id(33012456979076181423)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(58145301145361128614)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_HELP_TEXT'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_header=>'Type some place names, or click the map to set start and end coordinates.'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32981191814259991636)
,p_name=>'P7_TRAVEL_MODE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(33012457105608181424)
,p_item_default=>'DRIVING'
,p_prompt=>'Travel Mode'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Driving;DRIVING,Walking;WALKING,Bicycling;BICYCLING,Transit;TRANSIT'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(32992891965385320258)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33034686416542673825)
,p_name=>'P7_ORIGIN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(33012457105608181424)
,p_prompt=>'Origin'
,p_placeholder=>'lat,lng or address'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(32992891694697320257)
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_show_quick_picks=>'Y'
,p_quick_pick_label_01=>'sample'
,p_quick_pick_value_01=>'48.8810 2.3453'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33034686480889673826)
,p_name=>'P7_DEST'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(33012457105608181424)
,p_prompt=>'Destination'
,p_placeholder=>'lat,lng or address'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(32992891694697320257)
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_show_quick_picks=>'Y'
,p_quick_pick_label_01=>'sample'
,p_quick_pick_value_01=>'51.5321 -0.1239'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33034686560382673827)
,p_name=>'P7_DISTANCE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(33012457105608181424)
,p_prompt=>'Distance'
,p_post_element_text=>'m'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(32992891694697320257)
,p_item_icon_css_classes=>'fa-fit-to-width'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33034686705791673828)
,p_name=>'P7_DURATION'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(33012457105608181424)
,p_prompt=>'Duration'
,p_post_element_text=>'s'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(32992891694697320257)
,p_item_icon_css_classes=>'fa-clock-o'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33034686736950673829)
,p_name=>'P7_DISTANCE_KM'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(33012457105608181424)
,p_post_element_text=>'km'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(32992891694697320257)
,p_item_icon_css_classes=>'fa-fit-to-width'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33034686879917673830)
,p_name=>'P7_DURATION_MI'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(33012457105608181424)
,p_post_element_text=>'min'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(32992891694697320257)
,p_item_icon_css_classes=>'fa-clock-o'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(33034686994645673831)
,p_name=>'on change distance'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_DISTANCE'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33034687049997673832)
,p_event_id=>wwv_flow_api.id(33034686994645673831)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s("P7_DISTANCE_KM", Math.round(parseFloat($v("P7_DISTANCE"))/1000));'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(33034687218350673833)
,p_name=>'on change duration'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_DURATION'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33034687280438673834)
,p_event_id=>wwv_flow_api.id(33034687218350673833)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s("P7_DURATION_MI", Math.round(parseFloat($v("P7_DURATION"))/60));'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(33106454115615950317)
,p_name=>'mapclick'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(32991962266473031910)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|mapclick'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33106454178336950318)
,p_event_id=>wwv_flow_api.id(33106454115615950317)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v("P7_ORIGIN")=="") {',
'  $s("P7_ORIGIN", this.data.lat+","+this.data.lng);',
'} else {',
'  $s("P7_DEST", this.data.lat+","+this.data.lng);',
'}'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(32981189991058991618)
,p_name=>'directions'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(32991962266473031910)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|directions'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(32981190060412991619)
,p_event_id=>wwv_flow_api.id(32981189991058991618)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$s("P7_DISTANCE",this.data.distance);',
'$s("P7_DURATION",this.data.duration);',
'console.log("directions response object", this.data.directions);'))
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(32991961207527031899)
,p_name=>'on enter origin / dest'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P7_TRAVEL_MODE,P7_ORIGIN,P7_DEST'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(32991961257695031900)
,p_event_id=>wwv_flow_api.id(32991961207527031899)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#map_mymap").reportmap("showDirections", $v("P7_ORIGIN"), $v("P7_DEST"), $v("P7_TRAVEL_MODE"));'
);
wwv_flow_api.component_end;
end;
/
