prompt --application/pages/page_00024
begin
--   Manifest
--     PAGE: 00024
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>22940
,p_default_id_offset=>32959023425505623190
,p_default_owner=>'JK64'
);
wwv_flow_api.create_page(
 p_id=>24
,p_user_interface_id=>wwv_flow_api.id(58145327374438128653)
,p_name=>'Spiderfier'
,p_alias=>'SPIDERFIER'
,p_step_title=>'Spiderfier'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'This map shows the pins but if they are very close or overlapping, when the user clicks on the cluster it spreads them out ("spiderfies" them) with lines tracking them back to their original position. The user can then click the individual pins to ge'
||'t info about them.',
'<p>',
'Uses <a href="OverlappingMarkerSpiderfier" target=_blank>https://github.com/jawj/OverlappingMarkerSpiderfier</a>.',
'<p>',
'By default the plugin uses a function to format the pins so that they look different if they are spiderfied or not. To modify the formatting you can',
'    provide your own marker formatting function and specify it in the <b>JavaScript Initialization Code</b> attribute.',
'<p>',
'On this page, the plugin''s <b>JavaScript Initialization Code</b> has:',
'    <code>',
'    this.options.spiderfyFormatFn = function(marker, status) {',
'        var iconURL = ''https://mt.googleapis.com/vt/icon/name=icons/spotlight/''',
'            + (status == OverlappingMarkerSpiderfier.markerStatus.SPIDERFIED)',
'            ? ''spotlight-waypoint-blue.png''',
'            : ''spotlight-poi.png'';',
'        marker.setIcon({url: iconURL});',
'    };',
'    </code>',
'</p>'))
,p_last_updated_by=>'JEFF'
,p_last_upd_yyyymmddhh24miss=>'20200522210834'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33086439786804853633)
,p_plug_name=>'Visualisation: Spiderfier'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(58145301145361128614)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source_type=>'NATIVE_HELP_TEXT'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(36227406205379422813)
,p_plug_name=>'Report Map'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(58145301145361128614)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select c003 as lat, c004 as lng, c002 as name, c001 as id, c002 || '' (id='' || c001 || '')'' as info',
'from apex_collections',
'where collection_name = ''MAP'''))
,p_plug_source_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.debug("javascript init code");',
'',
'// set any non-default spiderfier options here',
'',
'// keepSpiderfied defaults to true',
'//this.options.spiderfier.keepSpiderfied = false;',
'',
'// Reference: https://github.com/jawj/OverlappingMarkerSpiderfier',
'',
'this.options.spiderfyFormatFn = function(marker, status) {',
'    var iconURL = ''https://mt.googleapis.com/vt/icon/name=icons/spotlight/''',
'        + ((status == OverlappingMarkerSpiderfier.markerStatus.SPIDERFIED)',
'          ? ''spotlight-waypoint-blue.png''',
'          : ''spotlight-poi.png'');',
'    marker.setIcon({url: iconURL});',
'};'))
,p_attribute_01=>'350'
,p_attribute_02=>'SPIDERFIER'
,p_attribute_04=>'PAN_ON_CLICK:PAN_ALLOWED:ZOOM_ALLOWED:SPINNER'
,p_attribute_22=>'ROADMAP'
,p_attribute_24=>'Y'
,p_attribute_25=>'auto'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33012933294376615205)
,p_name=>'P24_CLICKED'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(33086439786804853633)
,p_prompt=>'Pin data'
,p_placeholder=>'(click a map marker to show data here)'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>4000
,p_tag_attributes=>'readonly'
,p_field_template=>wwv_flow_api.id(32992891694697320257)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33012933656280615209)
,p_name=>'P24_POSITION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(33086439786804853633)
,p_prompt=>'Position'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(32992891694697320257)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(33012938089202615241)
,p_name=>'map loaded'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(36227406205379422813)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|maploaded'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33012938624279615241)
,p_event_id=>wwv_flow_api.id(33012938089202615241)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.debug("loaded",this.data.countPins,"pins");'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(33012936639527615238)
,p_name=>'marker clicked'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(36227406205379422813)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|markerclick'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33012937145642615240)
,p_event_id=>wwv_flow_api.id(33012936639527615238)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P24_CLICKED'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'"this.data.id=" + this.data.id + " this.data.name=" + this.data.name'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33012937699101615240)
,p_event_id=>wwv_flow_api.id(33012936639527615238)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P24_POSITION'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.data.lat + " " + this.data.lng'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.component_end;
end;
/
