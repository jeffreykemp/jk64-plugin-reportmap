prompt --application/pages/page_00021
begin
--   Manifest
--     PAGE: 00021
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>22940
,p_default_id_offset=>32959023425505623190
,p_default_owner=>'JK64'
);
wwv_flow_api.create_page(
 p_id=>21
,p_user_interface_id=>wwv_flow_api.id(58145327374438128653)
,p_name=>'Localisation'
,p_alias=>'LOCALISATION'
,p_step_title=>'Localisation'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3>Language</h3>',
'By default, the map uses the user''s preferred language setting as specified in the browser, when displaying textual information such as the names for controls, copyright notices, driving directions and labels on maps. In most cases, it''s preferable t'
||'o respect the browser setting. The language attribute on the plugin allows the developer to override the user''s preferred language.',
'</p>',
'<h3>Region</h3>',
'When you load the map it applies a default bias for application behavior towards the United States. If you want to alter your application to serve different map tiles or bias the application (such as biasing geocoding results towards the region), you'
||' can override this default behavior by setting the Region attribute.',
'<p>',
'Example: try searching for "Toledo" with the Region set to different values.'))
,p_last_updated_by=>'JEFF'
,p_last_upd_yyyymmddhh24miss=>'20200527155241'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33012458429642181438)
,p_plug_name=>'Search'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(58145301145361128614)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33079017451735284205)
,p_plug_name=>'Report Google Map Plugin'
,p_region_name=>'mymap'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(58145293116210128605)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'350'
,p_attribute_02=>'PINS'
,p_attribute_03=>'13'
,p_attribute_04=>'PAN_ON_CLICK:PAN_ALLOWED:ZOOM_ALLOWED:SPINNER'
,p_attribute_08=>'&P21_LANGUAGE.'
,p_attribute_09=>'&P21_REGION.'
,p_attribute_12=>'N'
,p_attribute_21=>'N'
,p_attribute_22=>'ROADMAP'
,p_attribute_24=>'Y'
,p_attribute_25=>'auto'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33155977335016312055)
,p_plug_name=>'Notes'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(58145301145361128614)
,p_plug_display_sequence=>30
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_HELP_TEXT'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33012457965009181433)
,p_name=>'P21_LANGUAGE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(33079017451735284205)
,p_prompt=>'Language'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Afrikaans;af,Arabic;ar,Chinese;zh,English;en,French;fr,German;de,Hebrew;iw,Hindi;hi,Italian;it,Japanese;ja,Korean;ko,Portuguese;pt,Spanish;es,Thai;th,Vietnamese;vi,Zulu;zu'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'(user''s preferred)'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(58145321701108128634)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33012458053744181434)
,p_name=>'P21_REGION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(33079017451735284205)
,p_prompt=>'Region'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Great Britain (gb);gb,Spain (es);es,Australia (au);au,Japan (jp);jp'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'(default - United States)'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(58145321701108128634)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--xlarge'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33012458155591181435)
,p_name=>'P21_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(33012458429642181438)
,p_prompt=>'Search by location'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_api.id(32992891694697320257)
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(33012458307592181436)
,p_name=>'on change'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P21_SEARCH'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33012458360841181437)
,p_event_id=>wwv_flow_api.id(33012458307592181436)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_DA_R1'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(33079017451735284205)
,p_attribute_01=>'gotoAddress'
,p_attribute_02=>'triggeringElement'
,p_attribute_07=>'zoom'
);
wwv_flow_api.component_end;
end;
/
