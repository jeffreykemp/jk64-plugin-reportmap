prompt --application/pages/page_00030
begin
--   Manifest
--     PAGE: 00030
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>22940
,p_default_id_offset=>32959023425505623190
,p_default_owner=>'JK64'
);
wwv_flow_api.create_page(
 p_id=>30
,p_user_interface_id=>wwv_flow_api.id(58145327374438128653)
,p_name=>'Source is Table or View'
,p_step_title=>'Source is Table or View'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'The map region has Source Type set to <b>Table / View</b>, with the source table <b>JK64DEMO_COUNTRIES_VW</b>.',
'<p><p>',
'The view is defined on the database as:',
'<pre>',
'create view jk64demo_countries_vw as',
'select lat, lng, country as name, rowid as id',
'from jk64demo_countries sample(10)',
'where lat is not null and lng is not null',
'</pre>',
'<p>',
'Using this source type requires that the source table or view provide columns with the right names. The columns required depend on what Visualisation is chosen. Look at the Source Help within APEX for more information.',
'<p>',
'Not all features, such as popup info windows and pin labels, are supported in this mode; for additional features, use the <b>SQL Query</b> or <b>PL/SQL Function returning SQL Query</b> source type instead.'))
,p_last_updated_by=>'JEFF'
,p_last_upd_yyyymmddhh24miss=>'20200619165255'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33158093708505767738)
,p_plug_name=>'Table or View'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(58145301145361128614)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_HELP_TEXT'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(36299060127080336918)
,p_plug_name=>'Report Map'
,p_region_name=>'mymap'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(58145301145361128614)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'TABLE'
,p_query_table=>'JK64DEMO_COUNTRIES_VW'
,p_include_rowid_column=>false
,p_plug_source_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plugin_init_javascript_code=>'apex.debug("javascript init code");'
,p_attribute_01=>'350'
,p_attribute_02=>'PINS'
,p_attribute_04=>'PAN_ON_CLICK:PAN_ALLOWED:ZOOM_ALLOWED:SPINNER'
,p_attribute_12=>'N'
,p_attribute_21=>'N'
,p_attribute_22=>'ROADMAP'
,p_attribute_24=>'Y'
,p_attribute_25=>'auto'
);
wwv_flow_api.component_end;
end;
/
