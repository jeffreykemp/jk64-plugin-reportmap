prompt --application/pages/page_00022
begin
--   Manifest
--     PAGE: 00022
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>22940
,p_default_id_offset=>32959023425505623190
,p_default_owner=>'JK64'
);
wwv_flow_api.create_page(
 p_id=>22
,p_user_interface_id=>wwv_flow_api.id(58145327374438128653)
,p_name=>'Load GeoJSON from database'
,p_alias=>'GEOJSON'
,p_step_title=>'Load GeoJSON from database'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'A Dynamic Action on the Country select list uses the APEX CLOB Load 2 plugin to load the geometry for the country''s borders into the hidden P22_GEOJSON item.',
'<p>',
'A Dynamic Action on P22_GEOJSON runs the JK64 Report Google Map R1 Action action "loadGeoJsonString", with the value based on the following JavaScript expression:',
'<p>',
'<code>',
'''{"type":"Feature","geometry":''+$v("P22_GEOJSON")+'',"properties":{"name":"''+$v("P22_COUNTRY")+''"}}''',
'</code>',
'</p>',
'Alternatively, to load GeoJSON onto the map programmatically, the following Javascript API call may instead be used:',
'<code>',
'$("#map_testmap").reportmap("loadGeoJsonString", ''...your geoJON here...'');',
'</code>',
'<p>',
'<hr>',
'Even better, you can load GeoJSON onto the map via the SQL Query.'))
,p_page_comment=>'This page requires the table jk64demo_countries.'
,p_last_updated_by=>'JEFF'
,p_last_upd_yyyymmddhh24miss=>'20200805111420'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33013000354989179514)
,p_plug_name=>'Geometry Data Not Loaded'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning'
,p_plug_template=>wwv_flow_api.id(58145291527774128598)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'This page requires the country border geometry loaded into the jk64demo_countries table.',
'<p>',
'To load this data, run <code>jk64demo_countries_geometry.sql</code>. You can download this script from <a href="https://github.com/jeffreykemp/jk64-plugin-reportmap/tree/master/demo_src" target=_blank>here</a>.'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NOT_EXISTS'
,p_plug_display_when_condition=>'select 1 from jk64demo_countries where geometry is not null'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33102288390891504382)
,p_plug_name=>'Info'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(58145301145361128614)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_HELP_TEXT'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33190602071031515597)
,p_plug_name=>'Load GeoJSON from database'
,p_region_name=>'testmap'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(58145301145361128614)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_item_display_point=>'BELOW'
,p_plug_source_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'400'
,p_attribute_02=>'PINS'
,p_attribute_04=>'PAN_ON_CLICK:DRAGGABLE:PAN_ALLOWED:ZOOM_ALLOWED:SPINNER'
,p_attribute_11=>wwv_flow_string.join(wwv_flow_t_varchar2(
'[',
'    {',
'        "featureType": "all",',
'        "elementType": "labels",',
'        "stylers": [',
'            {',
'                "visibility": "off"',
'            }',
'        ]',
'    },',
'    {',
'        "featureType": "administrative",',
'        "elementType": "all",',
'        "stylers": [',
'            {',
'                "visibility": "off"',
'            }',
'        ]',
'    },',
'    {',
'        "featureType": "landscape.man_made",',
'        "elementType": "all",',
'        "stylers": [',
'            {',
'                "visibility": "off"',
'            }',
'        ]',
'    },',
'    {',
'        "featureType": "poi",',
'        "elementType": "all",',
'        "stylers": [',
'            {',
'                "visibility": "off"',
'            }',
'        ]',
'    },',
'    {',
'        "featureType": "road",',
'        "elementType": "all",',
'        "stylers": [',
'            {',
'                "visibility": "off"',
'            }',
'        ]',
'    },',
'    {',
'        "featureType": "transit",',
'        "elementType": "all",',
'        "stylers": [',
'            {',
'                "visibility": "off"',
'            }',
'        ]',
'    }',
']'))
,p_attribute_22=>'ROADMAP'
,p_attribute_24=>'Y'
,p_attribute_25=>'greedy'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(32982793226184082629)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(33190602071031515597)
,p_button_name=>'DELETE_ALL_FEATURES'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(58145322218118128635)
,p_button_image_alt=>'Delete All Features'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(33013000724650179517)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(33102288390891504382)
,p_button_name=>'GEOJSON_VISUALISATION'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--link:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_api.id(58145322285602128635)
,p_button_image_alt=>'Load GeoJson via SQL'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:27:&SESSION.::&DEBUG.:RP::'
,p_icon_css_classes=>'fa-radar-chart'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(32982793570343082632)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_api.id(33190602071031515597)
,p_button_name=>'LOAD_ALL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(58145322218118128635)
,p_button_image_alt=>'Load All'
,p_button_position=>'BELOW_BOX'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33009354931231014175)
,p_name=>'P22_COUNTRY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(33190602071031515597)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Country'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select country || '' ('' || ceil(dbms_lob.getlength(geometry)/1024) || ''KB)'' as d',
'      ,country',
'from jk64demo_countries',
'where geometry is not null',
'and country != ''Antarctica''',
'order by country'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(58145321701108128634)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33009355342713014178)
,p_name=>'P22_GEOJSON'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(33190602071031515597)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(33016908681594465296)
,p_name=>'P22_NAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(33190602071031515597)
,p_prompt=>'Name'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(58145321546870128633)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(33009358096472014198)
,p_name=>'load country borders'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P22_COUNTRY'
,p_condition_element=>'P22_COUNTRY'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33009358558125014198)
,p_event_id=>wwv_flow_api.id(33009358096472014198)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_APEX.CLOB.LOAD.2'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select /* Element type dom - for jQuery selector e.g. body or #region-id, item - for item name e.g. P1_MY_ITEM */',
'    ''item'' AS ELEMENT_TYPE,',
'    /* jQuery selector or item name */',
'    ''P22_GEOJSON'' AS ELEMENT_SELECTOR,',
'    geometry as clob_value',
'from jk64demo_countries',
'where country = :P22_COUNTRY'))
,p_attribute_02=>'P22_COUNTRY'
,p_attribute_03=>'N'
,p_attribute_04=>'PRINT_CLOB'
,p_attribute_05=>'Y'
,p_attribute_10=>'N'
,p_attribute_13=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(32982793403209082630)
,p_name=>'on click delete all features'
,p_event_sequence=>130
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(32982793226184082629)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(32982793490805082631)
,p_event_id=>wwv_flow_api.id(32982793403209082630)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_DA_R1'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(33190602071031515597)
,p_attribute_01=>'deleteAllFeatures'
,p_attribute_02=>'triggeringElement'
,p_attribute_07=>'zoom'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(32982793693258082633)
,p_name=>'on click load all'
,p_event_sequence=>140
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(32982793570343082632)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33016909210095465301)
,p_event_id=>wwv_flow_api.id(32982793693258082633)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P22_NAME,P22_COUNTRY'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(32982794141124082638)
,p_event_id=>wwv_flow_api.id(32982793693258082633)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_APEX.CLOB.LOAD.2'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(33190602071031515597)
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select /* Element type dom - for jQuery selector e.g. body or #region-id, item - for item name e.g. P1_MY_ITEM */',
'    ''item'' AS ELEMENT_TYPE,',
'    /* jQuery selector or item name */',
'    ''P22_GEOJSON'' AS ELEMENT_SELECTOR,',
'    geometry as clob_value',
'from jk64demo_countries',
'where country != ''Antarctica''',
'and geometry is not null'))
,p_attribute_03=>'N'
,p_attribute_04=>'PRINT_CLOB'
,p_attribute_05=>'Y'
,p_attribute_10=>'N'
,p_attribute_13=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(32982793904860082635)
,p_name=>'on load geojson'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P22_GEOJSON'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(32982793981394082636)
,p_event_id=>wwv_flow_api.id(32982793904860082635)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_DA_R1'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(33190602071031515597)
,p_attribute_01=>'loadGeoJsonString'
,p_attribute_02=>'javascriptExpression'
,p_attribute_06=>'''{"type":"Feature","geometry":''+$v("P22_GEOJSON")+'',"properties":{"name":"''+$v("P22_COUNTRY")+''"}}'''
,p_attribute_07=>'zoom'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(33016908748413465297)
,p_name=>'mouse over feature'
,p_event_sequence=>160
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(33190602071031515597)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|mouseoverfeature'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33016908875157465298)
,p_event_id=>wwv_flow_api.id(33016908748413465297)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P22_NAME'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.data.feature.getProperty("name")'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(33016908932229465299)
,p_name=>'mouse out feature'
,p_event_sequence=>170
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(33190602071031515597)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|mouseoutfeature'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33016909077002465300)
,p_event_id=>wwv_flow_api.id(33016908932229465299)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P22_NAME'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.component_end;
end;
/
