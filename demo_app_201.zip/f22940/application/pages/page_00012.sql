prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>22940
,p_default_id_offset=>32959023425505623190
,p_default_owner=>'JK64'
);
wwv_flow_api.create_page(
 p_id=>12
,p_user_interface_id=>wwv_flow_api.id(58145327374438128653)
,p_name=>'Geolocate'
,p_alias=>'GEOLOCATE'
,p_step_title=>'Geolocate'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_page_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    Click the button to geolocate: find your current location. Your browser may ask your permission to provide this information to the page. This demo app doesn''t send that info anywhere; but you could code your app to do something with it if you nee'
||'ded to. The accuracy of the geolocation will depend on the user''s device.',
'</p><p>',
'    The button has a dynamic action that runs the Report Map Action <strong>"Go to Device Location"</strong>.',
'</p><p>',
'    The region has a Dynamic Action on the <b>geolocate</b> event which has two Actions:',
'<ol>',
'<li>Report Map Action <strong>"Set Zoom"</strong> to static value: 15',
'    </li>',
'<li><b>Set Value</b>: set item P12_CENTRE to JavaScript Expression:',
'<code>',
'this.data.lat+" "+this.data.lng',
'</code></li>',
'</ol>',
'</p><p>',
'    <a href="https://github.com/jeffreykemp/jk64-plugin-reportmap/wiki/Tip:-Zoom-to-user''s-current-location">Tip: Zoom to user''s current location</a>',
'</p>'))
,p_last_updated_by=>'JEFF'
,p_last_upd_yyyymmddhh24miss=>'20200805103341'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(32991962621894031913)
,p_plug_name=>'Map'
,p_region_name=>'mymap'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(58145293116210128605)
,p_plug_display_sequence=>20
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'400'
,p_attribute_02=>'PINS'
,p_attribute_03=>'13'
,p_attribute_04=>'PAN_ON_CLICK:PAN_ALLOWED:ZOOM_ALLOWED:SPINNER'
,p_attribute_12=>'N'
,p_attribute_21=>'N'
,p_attribute_22=>'ROADMAP'
,p_attribute_24=>'Y'
,p_attribute_25=>'auto'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(33094906799248709428)
,p_plug_name=>'Geolocate'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(58145301145361128614)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>5
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_HELP_TEXT'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(33094906881089709429)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(33094906799248709428)
,p_button_name=>'GEOLOCATE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--iconRight:t-Button--stretch'
,p_button_template_id=>wwv_flow_api.id(58145322285602128635)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Geolocate'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-bolt'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(32992414399777841599)
,p_name=>'P12_CENTRE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(33094906799248709428)
,p_prompt=>'Centre'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(32992891694697320257)
,p_item_icon_css_classes=>'fa-map-pin'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(33094907011146709430)
,p_name=>'geolocate'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(33094906881089709429)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(33094907091315709431)
,p_event_id=>wwv_flow_api.id(33094907011146709430)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_DA_R1'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(32991962621894031913)
,p_attribute_01=>'geolocate'
,p_attribute_02=>'triggeringElement'
,p_attribute_07=>'zoom'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(32992414440700841600)
,p_name=>'on geolocate'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(32991962621894031913)
,p_bind_type=>'bind'
,p_bind_event_type=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_R1|REGION TYPE|geolocate'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(32992414659520841602)
,p_event_id=>wwv_flow_api.id(32992414440700841600)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.JK64.REPORT_GOOGLE_MAP_DA_R1'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(32991962621894031913)
,p_attribute_01=>'setOption'
,p_attribute_02=>'static'
,p_attribute_05=>'15'
,p_attribute_07=>'zoom'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(32992414610700841601)
,p_event_id=>wwv_flow_api.id(32992414440700841600)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_CENTRE'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.data.lat+" "+this.data.lng'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.component_end;
end;
/
