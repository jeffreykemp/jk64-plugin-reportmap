prompt --application/deployment/install/upgrade_jk64demo_objects_sql
begin
--   Manifest
--     INSTALL: UPGRADE-jk64demo_objects.sql
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>69160808430820669492
,p_default_application_id=>22940
,p_default_id_offset=>32959023425505623190
,p_default_owner=>'JK64'
);
wwv_flow_api.create_install_script(
 p_id=>wwv_flow_api.id(33021851346515309263)
,p_install_id=>wwv_flow_api.id(33013455292971075769)
,p_name=>'jk64demo_objects.sql'
,p_sequence=>10
,p_script_type=>'UPGRADE'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'execute immediate q''[',
'create table jk64demo_countries',
'( country varchar2(255) not null',
', iso_a2 varchar2(2)',
', iso_a3 varchar2(3)',
', lat number',
', lng number',
', geometry clob',
', constraint country_name_uk unique (country)',
', constraint iso_a2_uk unique (iso_a2)',
', constraint iso_a3_uk unique (iso_a3)',
', constraint geometry_is_json check (geometry is json)',
')',
']'';',
'exception',
'when others then if sqlcode!=-955 then raise; end if;',
'end;',
'/',
'',
'create or replace force view jk64demo_countries_vw as',
'select lat, lng, country as name, rowid as id',
'from jk64demo_countries sample(10)',
'where lat is not null and lng is not null;',
'',
'begin',
'execute immediate q''[',
'create table jk64demo_earthquakes (	lat number not null, lng number not null, mag number not null )',
']'';',
'exception',
'when others then if sqlcode!=-955 then raise; end if;',
'end;',
'/',
''))
);
wwv_flow_api.component_end;
end;
/
